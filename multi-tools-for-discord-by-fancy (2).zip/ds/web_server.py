import asyncio
import base64
import json
import logging
import sys
import os
from typing import Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request, Form, HTTPException, UploadFile, File
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

from fancy_core import (
    TokenOperations, BotOperations, WebhookOperations, NitroOperations,
    ServerOperations, Validator, VoiceKicker, ClientFreezer, ServerCreator,
    OPUSLIB_AVAILABLE
)

API_SECRET = os.environ.get("FANCY_SECRET", "fancy_v1_secret_2024")

log_queue = asyncio.Queue(maxsize=1000)

class WebSocketLogHandler(logging.Handler):
    def emit(self, record):
        msg = self.format(record)
        try:
            log_queue.put_nowait(msg)
        except asyncio.QueueFull:
            pass

root_logger = logging.getLogger()
root_logger.handlers.clear()
root_logger.addHandler(logging.StreamHandler(sys.stdout))
ws_handler = WebSocketLogHandler()
ws_handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
root_logger.addHandler(ws_handler)
root_logger.setLevel(logging.INFO)

app = FastAPI(title="Fancy v1 Web Dashboard")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ConnectionManager:
    def __init__(self):
        self.active_connections = []
        self._active_tasks = {}

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)

    def add_task(self, task_id: str):
        self._active_tasks[task_id] = True

    def remove_task(self, task_id: str):
        self._active_tasks.pop(task_id, None)

    def has_task(self, task_id: str) -> bool:
        return task_id in self._active_tasks

manager = ConnectionManager()

def verify_secret(secret: str = Form(...)):
    if secret != API_SECRET:
        raise HTTPException(status_code=403, detail="неверный секретный ключ")
    return True

@app.websocket("/ws/logs")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            try:
                msg = await asyncio.wait_for(log_queue.get(), timeout=0.5)
                try:
                    await asyncio.wait_for(websocket.send_text(msg), timeout=5)
                except asyncio.TimeoutError:
                    pass
                except WebSocketDisconnect:
                    break
            except asyncio.QueueEmpty:
                await asyncio.sleep(0.5)
    except WebSocketDisconnect:
        pass
    except Exception:
        pass
    finally:
        manager.disconnect(websocket)

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    html_path = os.path.join(os.path.dirname(__file__), "templates", "index.html")
    with open(html_path, "r", encoding="utf-8") as f:
        html_content = f.read()
    return HTMLResponse(content=html_content)

@app.post("/api/nuke")
async def api_nuke(token: str = Form(...), guild_id: str = Form(...), secret: str = Form(...)):
    verify_secret(secret)
    op = TokenOperations(token)
    result = op.nuke_guild(guild_id)
    return {"status": "ok", "result": result}

@app.post("/api/info")
async def api_info(token: str = Form(...), secret: str = Form(...)):
    verify_secret(secret)
    op = TokenOperations(token)
    result = op.get_info()
    return {"status": "ok", "result": result}

@app.post("/api/join")
async def api_join(token: str = Form(...), invite_code: str = Form(...), secret: str = Form(...)):
    verify_secret(secret)
    op = TokenOperations(token)
    result = op.join_invite(invite_code)
    return {"status": "ok", "result": result}

@app.post("/api/leave")
async def api_leave(token: str = Form(...), guild_id: str = Form(...), secret: str = Form(...)):
    verify_secret(secret)
    op = TokenOperations(token)
    result = op.leave_guild(guild_id)
    return {"status": "ok", "result": result}

@app.post("/api/login")
async def api_login(email: str = Form(...), password: str = Form(...), captcha: Optional[str] = Form(None), secret: str = Form(...)):
    verify_secret(secret)
    op = TokenOperations()
    result = op.login(email, password, captcha)
    return {"status": "ok", "result": result}

@app.post("/api/decode")
async def api_decode(token: str = Form(...), secret: str = Form(...)):
    verify_secret(secret)
    op = TokenOperations(token)
    result = op.decode_token()
    return {"status": "ok", "result": result}

@app.post("/api/raid")
async def api_raid(token: str = Form(...), guild_id: str = Form(...), secret: str = Form(...)):
    verify_secret(secret)
    op = TokenOperations(token)
    result = op.raid_server(guild_id)
    return {"status": "ok", "result": result}

@app.post("/api/spam")
async def api_spam(token: str = Form(...), channel_id: str = Form(...), message: str = Form(...), count: int = Form(100), secret: str = Form(...)):
    verify_secret(secret)
    if count <= 0:
        return {"status": "error", "result": "количество должно быть положительным"}
    op = TokenOperations(token)
    result = op.spam_channel(channel_id, message, count)
    return {"status": "ok", "result": result}

@app.post("/api/spam_with_file")
async def api_spam_with_file(
    token: str = Form(...),
    channel_id: str = Form(...),
    message: str = Form(""),
    count: int = Form(1),
    file: UploadFile = File(...),
    secret: str = Form(...)
):
    verify_secret(secret)
    if count <= 0:
        return {"status": "error", "result": "количество должно быть положительным"}
    try:
        file_bytes = await file.read()
    except Exception:
        return {"status": "error", "result": "не удалось прочитать файл"}
    op = TokenOperations(token)
    result = op.spam_channel_with_file(channel_id, message, file_bytes, file.filename or "file", count)
    return {"status": "ok", "result": result}

@app.post("/api/delete_friends")
async def api_delete_friends(token: str = Form(...), secret: str = Form(...)):
    verify_secret(secret)
    op = TokenOperations(token)
    result = op.delete_friends()
    return {"status": "ok", "result": result}

@app.post("/api/block_friends")
async def api_block_friends(token: str = Form(...), secret: str = Form(...)):
    verify_secret(secret)
    op = TokenOperations(token)
    result = op.block_friends()
    return {"status": "ok", "result": result}

@app.post("/api/mass_dm")
async def api_mass_dm(token: str = Form(...), message: str = Form(...), secret: str = Form(...)):
    verify_secret(secret)
    op = TokenOperations(token)
    result = op.mass_dm(message)
    return {"status": "ok", "result": result}

@app.post("/api/delete_dms")
async def api_delete_dms(token: str = Form(...), secret: str = Form(...)):
    verify_secret(secret)
    op = TokenOperations(token)
    result = op.delete_dms()
    return {"status": "ok", "result": result}

@app.post("/api/set_status")
async def api_set_status(token: str = Form(...), status: str = Form(...), custom_text: Optional[str] = Form(None), secret: str = Form(...)):
    verify_secret(secret)
    op = TokenOperations(token)
    result = op.set_status(status, custom_text)
    return {"status": "ok", "result": result}

@app.post("/api/set_language")
async def api_set_language(token: str = Form(...), lang: str = Form("ru"), secret: str = Form(...)):
    verify_secret(secret)
    op = TokenOperations(token)
    result = op.set_language(lang)
    return {"status": "ok", "result": result}

@app.post("/api/set_house")
async def api_set_house(token: str = Form(...), house: str = Form("brilliance"), secret: str = Form(...)):
    verify_secret(secret)
    op = TokenOperations(token)
    result = op.set_house(house)
    return {"status": "ok", "result": result}

@app.post("/api/set_theme")
async def api_set_theme(token: str = Form(...), theme: str = Form("dark"), secret: str = Form(...)):
    verify_secret(secret)
    op = TokenOperations(token)
    result = op.set_theme(theme)
    return {"status": "ok", "result": result}

@app.post("/api/generate_token")
async def api_generate_token(secret: str = Form(...)):
    verify_secret(secret)
    result = TokenOperations.generate_token()
    return {"status": "ok", "result": result}

@app.post("/api/bot_nuke")
async def api_bot_nuke(bot_token: str = Form(...), guild_id: str = Form(...), secret: str = Form(...)):
    verify_secret(secret)
    result = BotOperations.nuke_guild(bot_token, guild_id)
    return {"status": "ok", "result": result}

@app.post("/api/bot_invite")
async def api_bot_invite(bot_token: str = Form(...), guild_id: str = Form(...), secret: str = Form(...)):
    verify_secret(secret)
    result = BotOperations.create_invite(bot_token, guild_id)
    return {"status": "ok", "result": result}

@app.post("/api/server_info")
async def api_server_info(token: str = Form(...), guild_id: str = Form(...), secret: str = Form(...)):
    verify_secret(secret)
    result = ServerOperations.get_info(token, guild_id)
    return {"status": "ok", "result": result}

@app.post("/api/nitro_generate")
async def api_nitro_generate(count: int = Form(10), secret: str = Form(...)):
    verify_secret(secret)
    result = NitroOperations.generate(count)
    return {"status": "ok", "result": result}

@app.post("/api/webhook_info")
async def api_webhook_info(url: str = Form(...), secret: str = Form(...)):
    verify_secret(secret)
    result = WebhookOperations.get_info(url)
    return {"status": "ok", "result": result}

@app.post("/api/webhook_delete")
async def api_webhook_delete(url: str = Form(...), secret: str = Form(...)):
    verify_secret(secret)
    result = WebhookOperations.delete(url)
    return {"status": "ok", "result": result}

@app.post("/api/webhook_spam")
async def api_webhook_spam(url: str = Form(...), message: str = Form(...), count: int = Form(100), mode: str = Form("normal"), secret: str = Form(...)):
    verify_secret(secret)
    result = WebhookOperations.spam(url, message, count, mode)
    return {"status": "ok", "result": result}

@app.post("/api/webhook_spam_with_file")
async def api_webhook_spam_with_file(
    url: str = Form(...),
    message: str = Form(""),
    count: int = Form(1),
    file: UploadFile = File(...),
    secret: str = Form(...)
):
    verify_secret(secret)
    if count <= 0:
        return {"status": "error", "result": "количество должно быть положительным"}
    try:
        file_bytes = await file.read()
    except Exception:
        return {"status": "error", "result": "не удалось прочитать файл"}
    result = WebhookOperations.spam_with_file(url, message, file_bytes, file.filename or "file", count)
    return {"status": "ok", "result": result}

@app.post("/api/webhook_generate")
async def api_webhook_generate(secret: str = Form(...)):
    verify_secret(secret)
    result = WebhookOperations.generate()
    return {"status": "ok", "result": result}

@app.post("/api/validate")
async def api_validate(type: str = Form(...), items: str = Form(...), secret: str = Form(...)):
    verify_secret(secret)
    items_list = [i.strip() for i in items.split('\n') if i.strip()]
    dispatcher = {
        "token": Validator.token, "nitro": Validator.nitro, "webhook": Validator.webhook,
        "server": lambda x: Validator.server(x, None), "invite": Validator.invite,
        "bot_token": Validator.bot_token, "user_id": Validator.user_id,
    }
    func = dispatcher.get(type)
    if not func:
        return {"status": "error", "result": "неизвестный тип"}
    results = []
    for item in items_list:
        res = func(item)
        results.append({"valid": res.valid, "type": res.type, "info": res.info, "status_code": res.status_code})
    return {"status": "ok", "results": results}

@app.post("/api/voice_attack")
async def api_voice_attack(token: str = Form(...), guild_id: int = Form(...), channel_id: int = Form(...), secret: str = Form(...)):
    verify_secret(secret)
    if not OPUSLIB_AVAILABLE:
        return {"status": "error", "result": "opuslib не установлен"}
    task_id = f"voice_{guild_id}_{channel_id}"
    if manager.has_task(task_id):
        return {"status": "error", "result": "голосовая атака уже запущена в этом канале"}
    manager.add_task(task_id)
    kicker = VoiceKicker(token)
    async def run_kicker():
        try:
            await kicker.execute(guild_id, channel_id)
        finally:
            manager.remove_task(task_id)
    asyncio.create_task(run_kicker())
    return {"status": "ok", "result": "голосовая атака запущена"}

@app.post("/api/freezer")
async def api_freezer(token: str = Form(...), guild_id: int = Form(...), channel_id: int = Form(...), secret: str = Form(...)):
    verify_secret(secret)
    task_id = f"freezer_{guild_id}_{channel_id}"
    if manager.has_task(task_id):
        return {"status": "error", "result": "фризер уже запущен в этом канале"}
    manager.add_task(task_id)
    freezer = ClientFreezer(token)
    async def run_freezer():
        try:
            await freezer.execute(guild_id, channel_id)
        finally:
            manager.remove_task(task_id)
    asyncio.create_task(run_freezer())
    return {"status": "ok", "result": "фризер запущен"}

@app.post("/api/create_server")
async def api_create_server(
    token: str = Form(...),
    config_json: str = Form(...),
    icon: Optional[UploadFile] = File(None),
    secret: str = Form(...)
):
    verify_secret(secret)
    try:
        config = json.loads(config_json)
    except Exception as e:
        return {"status": "error", "result": f"невалидный JSON: {e}"}
    if icon and icon.filename:
        try:
            icon_bytes = await icon.read()
            config["icon_data"] = base64.b64encode(icon_bytes).decode('utf-8')
        except Exception:
            pass
    creator = ServerCreator(token)
    guild_id = creator.build(config)
    if guild_id:
        return {"status": "ok", "result": f"сервер создан: {guild_id}", "guild_id": guild_id}
    else:
        return {"status": "error", "result": "ошибка создания сервера"}

def run_web_server(port: int = 28681):
    uvicorn.run(app, host="127.0.0.1", port=port, log_level="info")